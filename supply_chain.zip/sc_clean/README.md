# NEXUS — Supply Chain Intelligence Platform

> **Advanced Data Structures & Algorithms (ADSA) Project**
> A real-time supply chain optimization platform using graph algorithms, network flow, and dynamic programming.

---

## 🏗 Architecture Overview

```
┌─────────────────────────────────────────────────────────────────┐
│                     NEXUS Frontend (Leaflet.js)                 │
│  ┌───────────┐  ┌──────────────┐  ┌──────────┐  ┌───────────┐  │
│  │  Map View  │  │ Truck Panel  │  │ Orders   │  │ Metrics   │  │
│  └─────┬─────┘  └──────┬───────┘  └────┬─────┘  └─────┬─────┘  │
│        └───────────────┴───────────────┴───────────────┘        │
│                          REST API (JSON)                        │
├─────────────────────────────────────────────────────────────────┤
│                    Flask Backend (Python)                        │
│  ┌──────────┐  ┌─────────────┐  ┌────────────┐  ┌───────────┐  │
│  │ StateManager│  GraphBuilder│  │  Simulator │  │  Models   │  │
│  └──────┬───┘  └──────┬──────┘  └─────┬──────┘  └───────────┘  │
│         └─────────────┴───────────────┘                         │
│                  Optimization Pipeline                           │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────────┐    │
│  │ Min-Cost │→ │  CVRP    │→ │ DP-TSP   │→ │ A* Routing   │    │
│  │  Flow    │  │ + 2-opt  │  │Held-Karp │  │ + Dijkstra   │    │
│  └──────────┘  └──────────┘  └──────────┘  └──────────────┘    │
└─────────────────────────────────────────────────────────────────┘
```

## 🧠 Algorithm Suite & Complexity Analysis

### 1. Shortest Path — Dijkstra / A* / Bidirectional A*

| Algorithm | Time Complexity | Space | Use Case |
|-----------|----------------|-------|----------|
| Dijkstra | O((V+E) · log V) | O(V) | All-pairs routing for cost matrix |
| A* (haversine) | O((V+E) · log V) | O(V) | Single-pair routing (faster in practice) |
| Bidirectional A* | O((V+E) · log V) | O(V) | Long-distance queries (~50% fewer nodes explored) |
| Bellman-Ford | O(V · E) | O(V) | Fallback for negative edge weights |

**Data Structures:** Binary heap (priority queue), adjacency list (NetworkX DiGraph).

### 2. Min-Cost Flow — Warehouse-to-Order Assignment

| Component | Time | Space |
|-----------|------|-------|
| Flow network construction | O(K · N) | O(K · N) |
| Successive Shortest Paths | O(V · E · log V) | O(V + E) |
| Greedy fallback | O(N · K · log N) | O(N) |

Where K = warehouses, N = orders, V = K + N + 2 (source/sink), E = K·N + K + N.

**Data Structures:** Directed graph with capacity/cost attributes, bipartite flow network.

### 3. CVRP — Capacitated Vehicle Routing

| Phase | Time | Description |
|-------|------|-------------|
| Greedy construction | O(N² · K) | Nearest-neighbour per truck |
| 2-opt improvement | O(N³) worst | Edge-swap local search (restarts on improvement) |
| Or-opt (single relocation) | O(N²) per pass | Complement to 2-opt for sequencing |
| Inter-route rebalance | O(N · K) | Best-fit stop transfer between trucks |

**Data Structures:** Ordered lists for routes, hash maps for cost lookups.

### 4. Held-Karp DP-TSP — Exact Travelling Salesman

| N (stops) | States | Memory | Time |
|-----------|--------|--------|------|
| 5 | 160 | < 1 KB | < 1 ms |
| 10 | 10,240 | ~80 KB | < 5 ms |
| 15 | 491,520 | ~4 MB | < 50 ms |
| 20 | 20,971,520 | ~160 MB | Skipped (too slow) |

**Recurrence:** `dp[mask | (1<<j)][j] = min{ dp[mask][i] + cost[i][j] }` for all i in mask

**Data Structures:** 2D NumPy array (N × 2^N bitmask table), parent-pointer backtracking.

### 5. Graph Builder — Road Network

**Data Structure:** NetworkX DiGraph with weighted, directed edges.

| Operation | Complexity |
|-----------|-----------|
| Add node | O(1) |
| Add edge (with haversine) | O(1) |
| Set traffic | O(1) |
| Connectivity check | O(V + E) via BFS |
| Connect all-to-all | O(V²) |

### 6. State Manager — Thread-Safe In-Memory Store

**Thread Safety:** `threading.RLock` for all mutations. Reentrant to allow nested operations.

**Data Structures:** `dict[str, Entity]` for O(1) lookup by ID, distance cache for memoized routing.

---

## 📁 Project Structure

```
supply_chain_improved/
├── README.md                      # This file
├── requirements.txt               # Python dependencies
├── backend/
│   ├── app.py                     # Flask REST API (17 endpoints)
│   ├── models.py                  # Domain entities (dataclasses)
│   ├── state.py                   # Thread-safe state manager
│   ├── graph_builder.py           # NetworkX road network
│   ├── .env                       # Environment configuration
│   ├── conftest.py                # Pytest path setup
│   ├── pytest.ini                 # Pytest configuration
│   ├── algorithms/
│   │   ├── __init__.py            # Package exports
│   │   ├── dijkstra.py            # Dijkstra, A*, Bidirectional A*
│   │   ├── min_cost_flow.py       # MCF assignment solver
│   │   ├── vrp.py                 # CVRP with 2-opt + Or-opt
│   │   ├── dp_tsp.py              # Held-Karp bitmask DP
│   │   ├── optimizer.py           # 4-stage pipeline orchestrator
│   │   └── simulator.py           # Demand/traffic event generator
│   └── tests/
│       ├── conftest.py            # Test path setup
│       ├── test_phase1.py         # Models, graph, state tests (24 tests)
│       ├── test_phase2.py         # Algorithm unit tests (28 tests)
│       ├── test_phase3.py         # REST API integration tests (34 tests)
│       └── test_edge_cases.py     # Edge case + regression tests (22 tests)
└── frontend/
    └── index.html                 # Single-file dark-themed dashboard
```

---

## 🚀 Getting Started

### Prerequisites
- Python 3.10+
- pip

### Installation

```bash
# Clone or extract the project
cd supply_chain_improved

# Install dependencies
pip install -r requirements.txt

# Start the backend server
cd backend
python app.py
```

The server starts at `http://localhost:5000`.

### Open the Frontend

Open `frontend/index.html` in a browser. It connects to the Flask API automatically.

### Run Tests

```bash
cd backend

# Run all tests with pytest
python -m pytest tests/ -v

# Or run individual test phases
python tests/test_phase1.py    # Models & state
python tests/test_phase2.py    # Algorithms
python tests/test_phase3.py    # API integration
python tests/test_edge_cases.py # Edge cases
```

---

## 🔌 API Reference

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/health` | Server health + uptime |
| GET | `/api/state` | Full system snapshot |
| GET | `/api/metrics` | Live performance metrics |
| GET | `/api/traffic` | Traffic congestion summary |
| POST | `/api/optimize` | Run 4-stage optimization |
| POST | `/api/orders` | Place a new order |
| GET | `/api/orders` | List orders (filter by ?status=) |
| POST | `/api/orders/:id/deliver` | Mark order delivered |
| POST | `/api/orders/deliver-all` | Deliver all in-transit orders |
| POST | `/api/warehouses` | Add a warehouse |
| GET | `/api/warehouses` | List warehouses |
| POST | `/api/delivery-points` | Add a delivery point |
| GET | `/api/delivery-points` | List delivery points |
| POST | `/api/trucks` | Add a truck |
| GET | `/api/trucks` | List trucks |
| GET | `/api/route/:src/:tgt` | Find shortest path |
| POST | `/api/simulate` | Demand spike + traffic event |
| POST | `/api/simulate/demand` | Demand spike only |
| POST | `/api/simulate/traffic` | Traffic event only |
| POST | `/api/reset/traffic` | Clear all traffic |
| POST | `/api/reset` | Hard reset (reload seed data) |

---

## 🧪 Test Coverage

| Test File | Tests | Coverage Area |
|-----------|-------|---------------|
| `test_phase1.py` | 24 | Models, GraphBuilder, StateManager, seed data |
| `test_phase2.py` | 28 | Dijkstra, A*, MCF, VRP, DP-TSP, Simulator, Optimizer |
| `test_phase3.py` | 34 | All REST API endpoints, validation, error handling |
| `test_edge_cases.py` | 22 | Disconnected graphs, infeasibility, thread safety |
| **Total** | **108** | |

---

## ⚙️ Configuration

Environment variables in `backend/.env`:

| Variable | Default | Description |
|----------|---------|-------------|
| `FLASK_PORT` | 5000 | Server port |
| `FLASK_DEBUG` | True | Debug mode |
| `DEFAULT_TRUCK_SPEED_KMH` | 60 | Truck speed for ETA |
| `DEFAULT_TRUCK_CAPACITY_KG` | 1000 | Default truck capacity |
| `DP_TSP_MAX_NODES` | 15 | Max stops for exact TSP |
| `VRP_MAX_ITERATIONS` | 1000 | Max 2-opt iterations |

---

## 🔐 Design Decisions

1. **In-memory state** — No database; `StateManager` holds all data in Python dicts for maximum speed. Suitable for this ADSA demonstration.

2. **Thread safety** — `threading.RLock` protects all state mutations. Reentrant to allow nested lock acquisition during optimization.

3. **4-stage pipeline** — Global optimum (MCF) → local routes (VRP) → exact refinement (TSP) → path resolution (A*). Each stage improves on the previous.

4. **Sentinel costs** — `9999.0` raw × 1000 scale factor = `9_999_000` integer sentinel for unreachable nodes in the flow network. Avoids `float('inf')` in integer-only NetworkX MCF.

5. **NumPy acceleration** — Held-Karp DP table uses NumPy arrays for ~10× speedup over pure Python lists.

6. **Haversine heuristic** — A* uses great-circle distance as an admissible (never overestimates) heuristic for geographic routing.
