"""
state.py — Centralized in-memory state manager.

Acts as the application's runtime database. Holds all warehouses, trucks,
orders, and delivery points. Provides thread-safe-ish mutation methods
and a clean snapshot API for the frontend.

In a production system this would be backed by Redis or PostgreSQL.
For this DSA project, an in-memory dict store is sufficient and fast.
"""

from __future__ import annotations
import threading
from typing import Optional
import time

from models import (
    Warehouse, DeliveryPoint, Truck, Order,
    OrderStatus, TruckStatus, Coordinates
)
from graph_builder import GraphBuilder

class StateManager:
    """
    Single shared state object — instantiated once and imported everywhere.

    Thread safety: all mutation methods acquire self._lock (a reentrant lock)
    so concurrent POST /api/optimize calls cannot interleave state writes.
    Read-only methods (get_*, snapshot) are safe without the lock because
    CPython's GIL protects dict reads; however callers that need a consistent
    cross-field view should hold the lock externally.

    Attributes:
        warehouses      : id → Warehouse
        delivery_points : id → DeliveryPoint
        trucks          : id → Truck
        orders          : id → Order
        graph           : GraphBuilder (the live road network)
        metrics         : running stats for the dashboard
    """

    def __init__(self):
        self._lock = threading.RLock()
        self.warehouses:        dict[str, Warehouse]      = {}
        self.delivery_points:   dict[str, DeliveryPoint]  = {}
        self.trucks:            dict[str, Truck]          = {}
        self.orders:            dict[str, Order]          = {}
        self.graph:             GraphBuilder              = GraphBuilder()
        self._created_at:       float                     = time.time()
        self._optimization_count: int                     = 0
        self._total_deliveries: int                       = 0
        # This avoids recomputing the same Dijkstra all-pairs in MCF, VRP, and DP-TSP stages.
        self._dist_cache: dict | None                     = None

    # ------------------------------------------------------------------
    # Warehouse operations
    # ------------------------------------------------------------------

    def add_warehouse(self, warehouse: Warehouse) -> Warehouse:
        with self._lock:
            self.warehouses[warehouse.id] = warehouse
            self.graph.add_warehouse(warehouse)
            for dp_id in self.delivery_points:
                if not self.graph.edge_exists(warehouse.id, dp_id):
                    self.graph.add_edge(warehouse.id, dp_id, bidirectional=True)
            for wh_id in self.warehouses:
                if wh_id != warehouse.id and not self.graph.edge_exists(warehouse.id, wh_id):
                    self.graph.add_edge(warehouse.id, wh_id, bidirectional=True)
            self._dist_cache = None
            return warehouse

    def get_warehouse(self, warehouse_id: str) -> Optional[Warehouse]:
        return self.warehouses.get(warehouse_id)

    def remove_warehouse(self, warehouse_id: str) -> bool:
        with self._lock:
            if warehouse_id not in self.warehouses:
                return False
            del self.warehouses[warehouse_id]
            self.graph.remove_node(warehouse_id)
            for truck in self.trucks.values():
                if truck.warehouse_id == warehouse_id:
                    truck.status = TruckStatus.IDLE
            self._dist_cache = None
            return True

    # ------------------------------------------------------------------
    # Delivery point operations
    # ------------------------------------------------------------------

    def add_delivery_point(self, dp: DeliveryPoint) -> DeliveryPoint:
        with self._lock:
            self.delivery_points[dp.id] = dp
            self.graph.add_delivery_point(dp)
            for wh_id in self.warehouses:
                if not self.graph.edge_exists(wh_id, dp.id):
                    self.graph.add_edge(wh_id, dp.id, bidirectional=True)
            for other_id in self.delivery_points:
                if other_id != dp.id and not self.graph.edge_exists(other_id, dp.id):
                    self.graph.add_edge(other_id, dp.id, bidirectional=True)
            self._dist_cache = None
            return dp

    def get_delivery_point(self, dp_id: str) -> Optional[DeliveryPoint]:
        return self.delivery_points.get(dp_id)

    # ------------------------------------------------------------------
    # Truck operations
    # ------------------------------------------------------------------

    def add_truck(self, truck: Truck) -> Truck:
        with self._lock:
            if truck.warehouse_id not in self.warehouses:
                raise ValueError(f"Warehouse '{truck.warehouse_id}' does not exist")
            self.trucks[truck.id] = truck
            return truck

    def get_truck(self, truck_id: str) -> Optional[Truck]:
        return self.trucks.get(truck_id)

    def get_idle_trucks(self) -> list[Truck]:
        return [t for t in self.trucks.values() if t.status == TruckStatus.IDLE]

    def get_trucks_for_warehouse(self, warehouse_id: str) -> list[Truck]:
        return [t for t in self.trucks.values() if t.warehouse_id == warehouse_id]

    # ------------------------------------------------------------------
    # Order operations
    # ------------------------------------------------------------------

    def add_order(self, order: Order) -> Order:
        with self._lock:
            if order.destination_id not in self.delivery_points:
                raise ValueError(f"Delivery point '{order.destination_id}' does not exist")
            self.orders[order.id] = order
            return order

    def get_order(self, order_id: str) -> Optional[Order]:
        return self.orders.get(order_id)

    def get_pending_orders(self) -> list[Order]:
        return [o for o in self.orders.values() if o.status == OrderStatus.PENDING]

    def get_orders_by_status(self, status: OrderStatus) -> list[Order]:
        return [o for o in self.orders.values() if o.status == status]

    def mark_order_delivered(self, order_id: str) -> bool:
        with self._lock:
            order = self.orders.get(order_id)
            if not order:
                return False
            order.mark_delivered()
            self._total_deliveries += 1
            return True

    # ------------------------------------------------------------------
    # Bulk snapshot — used by /state API
    # ------------------------------------------------------------------

    def snapshot(self) -> dict:
        """
        Return a full serializable snapshot of the current state.
        Called by the frontend every ~2 seconds to refresh the dashboard.
        """
        pending   = self.get_pending_orders()
        assigned  = self.get_orders_by_status(OrderStatus.ASSIGNED)
        in_transit = self.get_orders_by_status(OrderStatus.IN_TRANSIT)
        delivered = self.get_orders_by_status(OrderStatus.DELIVERED)

        active_trucks = [t for t in self.trucks.values() if t.status != TruckStatus.IDLE]
        total_load_kg = sum(t.current_load for t in active_trucks)

        return {
            "warehouses":      [wh.to_dict() for wh in self.warehouses.values()],
            "delivery_points": [dp.to_dict() for dp in self.delivery_points.values()],
            "trucks":          [t.to_dict()  for t  in self.trucks.values()],
            "orders":          [o.to_dict()  for o  in self.orders.values()],
            "graph":           self.graph.to_dict(),
            "metrics": {
                "total_warehouses":      len(self.warehouses),
                "total_trucks":          len(self.trucks),
                "idle_trucks":           len(self.get_idle_trucks()),
                "active_trucks":         len(active_trucks),
                "total_orders":          len(self.orders),
                "pending_orders":        len(pending),
                "assigned_orders":       len(assigned),
                "in_transit_orders":     len(in_transit),
                "delivered_orders":      len(delivered),
                "total_deliveries":      self._total_deliveries,
                "total_load_in_transit": round(total_load_kg, 2),
                "optimization_runs":     self._optimization_count,
                "uptime_seconds":        round(time.time() - self._created_at, 1),
            }
        }

    def increment_optimization_count(self) -> None:
        with self._lock:
            self._optimization_count += 1

    # ------------------------------------------------------------------
    # ------------------------------------------------------------------

    def get_all_pairs_costs(self, sources: list[str], targets: list[str]) -> dict:
        """

        Previously this method existed but was never called — the cache was
        a dead field. Now the optimizer calls this at Stage 3 (DP-TSP) and
        the result is stored so repeated calls with the same node sets are O(1).

        Cache key: sorted tuples of sources and targets (order-independent).
        Cache is invalidated whenever the graph topology or weights change
        (add/remove node, add/remove edge, set_traffic).
        """
        from algorithms.dijkstra import dijkstra_all_pairs
        # Sorted so that (["a","b"], ["c"]) and (["b","a"], ["c"]) hit the same key
        cache_key = (tuple(sorted(sources)), tuple(sorted(targets)))
        if self._dist_cache is None:
            self._dist_cache = {}
        if cache_key not in self._dist_cache:
            self._dist_cache[cache_key] = dijkstra_all_pairs(self.graph, sources, targets)
        return self._dist_cache[cache_key]

    def invalidate_dist_cache(self) -> None:
        """Invalidate the all-pairs cache. Called after any graph topology or weight change."""
        self._dist_cache = None

    # ------------------------------------------------------------------
    # Reset — used by /reset API
    # ------------------------------------------------------------------

    def hard_reset(self) -> None:
        """Wipe all runtime state and reload seed data."""
        with self._lock:
            self.warehouses       = {}
            self.delivery_points  = {}
            self.trucks           = {}
            self.orders           = {}
            self.graph            = GraphBuilder()
            self._optimization_count = 0
            self._total_deliveries   = 0
            self._created_at         = time.time()
            self._dist_cache         = None

# ---------------------------------------------------------------------------
# Seed data loader
# ---------------------------------------------------------------------------

def load_seed_data(state: StateManager) -> None:
    """
    Populate the state with a realistic Indian metro delivery network.

    Uses real latitude/longitude coordinates for Mumbai, Delhi, Bangalore,
    Chennai, Hyderabad, Pune, and Kolkata — so the Leaflet map renders
    a geographically accurate network.
    """

    # — Warehouses (major logistics hubs) —
    warehouses = [
        Warehouse("Mumbai Central WH",    Coordinates(19.0760, 72.8777), capacity_kg=5000, inventory=4000),
        Warehouse("Delhi NCR WH",         Coordinates(28.6139, 77.2090), capacity_kg=6000, inventory=5000),
        Warehouse("Bangalore WH",         Coordinates(12.9716, 77.5946), capacity_kg=4000, inventory=3500),
        Warehouse("Chennai WH",           Coordinates(13.0827, 80.2707), capacity_kg=3500, inventory=3000),
        Warehouse("Hyderabad WH",         Coordinates(17.3850, 78.4867), capacity_kg=4500, inventory=4000),
    ]

    # — Delivery points (stores, customers, distribution hubs) —
    delivery_points = [
        DeliveryPoint("Pune Store",        Coordinates(18.5204, 73.8567), demand_kg=200),
        DeliveryPoint("Surat Hub",         Coordinates(21.1702, 72.8311), demand_kg=150),
        DeliveryPoint("Jaipur Store",      Coordinates(26.9124, 75.7873), demand_kg=180),
        DeliveryPoint("Lucknow Hub",       Coordinates(26.8467, 80.9462), demand_kg=160),
        DeliveryPoint("Kolkata East",      Coordinates(22.5726, 88.3639), demand_kg=220),
        DeliveryPoint("Coimbatore Store",  Coordinates(11.0168, 76.9558), demand_kg=130),
        DeliveryPoint("Vizag Port",        Coordinates(17.6868, 83.2185), demand_kg=190),
        DeliveryPoint("Nagpur Hub",        Coordinates(21.1458, 79.0882), demand_kg=170),
        DeliveryPoint("Ahmedabad Store",   Coordinates(23.0225, 72.5714), demand_kg=210),
        DeliveryPoint("Kochi Port",        Coordinates(9.9312,  76.2673), demand_kg=140),
    ]

    for wh in warehouses:
        state.add_warehouse(wh)

    for dp in delivery_points:
        state.add_delivery_point(dp)

    # — Trucks (2–3 per warehouse) —
    truck_configs = [
        # (warehouse_name_fragment, truck_name, capacity, speed)
        ("Mumbai",    "MUM-T1", 1200, 65),
        ("Mumbai",    "MUM-T2",  900, 70),
        ("Mumbai",    "MUM-T3", 1500, 55),
        ("Delhi",     "DEL-T1", 1400, 60),
        ("Delhi",     "DEL-T2", 1000, 65),
        ("Delhi",     "DEL-T3", 1100, 60),
        ("Bangalore", "BLR-T1", 1000, 65),
        ("Bangalore", "BLR-T2",  800, 70),
        ("Chennai",   "CHE-T1",  900, 65),
        ("Chennai",   "CHE-T2", 1100, 60),
        ("Hyderabad", "HYD-T1", 1200, 65),
        ("Hyderabad", "HYD-T2",  950, 70),
    ]

    wh_map = {wh.name: wh.id for wh in warehouses}

    for wh_fragment, truck_name, cap, speed in truck_configs:
        wh_id = next(
            (wh_id for wh_name, wh_id in wh_map.items() if wh_fragment in wh_name),
            None
        )
        if wh_id:
            truck = Truck(
                warehouse_id=wh_id,
                name=truck_name,
                capacity_kg=cap,
                speed_kmh=speed,
            )
            state.add_truck(truck)

