"""
algorithms/dp_tsp.py — Exact TSP solver via Held-Karp bitmask DP.

"""

from __future__ import annotations
from dataclasses import dataclass
from typing import Optional

DP_MAX_NODES = 15   # above this, skip DP and keep VRP order

@dataclass
class TSPResult:
    optimal_order:   list[int]
    optimal_cost:    float
    applied:         bool
    improvement:     float = 0.0

    def to_dict(self) -> dict:
        return {
            "optimal_order": self.optimal_order,
            "optimal_cost":  round(self.optimal_cost, 2),
            "applied":       self.applied,
            "improvement":   round(self.improvement, 2),
        }

class DPTSPSolver:
    """
    Held-Karp bitmask DP for exact TSP on small instances (N <= 15).

    start_idx bit is set. This is the standard Held-Karp optimization:
    any valid partial tour must include the starting node, so roughly
    half of all 2^N masks are provably unreachable and can be skipped.

    Implementation: we iterate only over masks in the range where
    bit start_idx is set, by starting at (1 << start_idx) and using
    the popcount trick. In practice, the simplest correct approach is
    to filter with `if not (mask & (1 << start_idx)): continue` at the
    top of the loop — this is what the original code already did for
    the inner i-loop, but NOT for the outer mask loop. The fix adds the
    equivalent early-continue for masks.
    """

    def solve(
        self,
        cost_matrix: list[list[float]],
        n_stops:     int,
        start_idx:   int = 0,
    ) -> TSPResult:
        if n_stops <= 1:
            return TSPResult([0], 0.0, True, 0.0)

        if n_stops > DP_MAX_NODES:
            return TSPResult(list(range(n_stops)), float('inf'), False, 0.0)

        try:
            import numpy as np
            return self._solve_numpy(cost_matrix, n_stops, start_idx)
        except ImportError:
            return self._solve_pure_python(cost_matrix, n_stops, start_idx)

    def _solve_numpy(
        self,
        cost_matrix: list[list[float]],
        n_stops:     int,
        start_idx:   int,
    ) -> TSPResult:
        """NumPy-backed Held-Karp."""
        import numpy as np

        INF = float('inf')
        N = n_stops
        FULL_MASK = (1 << N) - 1
        START_BIT = (1 << start_idx)

        dp     = np.full((1 << N, N), INF, dtype=np.float64)
        parent = np.full((1 << N, N), -1,  dtype=np.int32)
        cost   = np.array(cost_matrix, dtype=np.float64)

        dp[START_BIT, start_idx] = 0.0

        for mask in range(1 << N):
            # no valid partial tour can exist without having visited start.
            if not (mask & START_BIT):
                continue

            for i in range(N):
                if not (mask & (1 << i)):
                    continue
                if dp[mask, i] == INF:
                    continue
                g = dp[mask, i]
                for j in range(N):
                    if mask & (1 << j):
                        continue
                    new_mask = mask | (1 << j)
                    new_cost = g + cost[i, j]
                    if new_cost < dp[new_mask, j]:
                        dp[new_mask, j] = new_cost
                        parent[new_mask, j] = i

        best_cost = INF
        last_node = -1
        for i in range(N):
            if i == start_idx:
                continue
            total = dp[FULL_MASK, i] + cost[i, start_idx]
            if total < best_cost:
                best_cost = total
                last_node = i

        if last_node == -1:
            return TSPResult(list(range(N)), INF, True, 0.0)

        path = []
        mask = FULL_MASK
        node = last_node
        while node != -1:
            path.append(int(node))
            prev = int(parent[mask, node])
            mask ^= (1 << node)
            node = prev if prev >= 0 else -1
        path.reverse()

        return TSPResult(optimal_order=path, optimal_cost=float(best_cost), applied=True)

    def _solve_pure_python(
        self,
        cost_matrix: list[list[float]],
        n_stops:     int,
        start_idx:   int,
    ) -> TSPResult:
        """Fallback pure-Python Held-Karp."""
        INF = float('inf')
        N = n_stops
        FULL_MASK = (1 << N) - 1
        START_BIT = (1 << start_idx)

        dp:     list[list[float]] = [[INF] * N for _ in range(1 << N)]
        parent: list[list[int]]   = [[-1]  * N for _ in range(1 << N)]

        dp[START_BIT][start_idx] = 0.0

        for mask in range(1 << N):
            if not (mask & START_BIT):
                continue

            for i in range(N):
                if not (mask & (1 << i)):
                    continue
                if dp[mask][i] == INF:
                    continue
                for j in range(N):
                    if mask & (1 << j):
                        continue
                    new_mask = mask | (1 << j)
                    new_cost = dp[mask][i] + cost_matrix[i][j]
                    if new_cost < dp[new_mask][j]:
                        dp[new_mask][j] = new_cost
                        parent[new_mask][j] = i

        best_cost = INF
        last_node = -1
        for i in range(N):
            if i == start_idx:
                continue
            total = dp[FULL_MASK][i] + cost_matrix[i][start_idx]
            if total < best_cost:
                best_cost = total
                last_node = i

        if last_node == -1:
            return TSPResult(list(range(N)), INF, True, 0.0)

        path = []
        mask = FULL_MASK
        node = last_node
        while node != -1:
            path.append(node)
            prev = parent[mask][node]
            mask ^= (1 << node)
            node = prev
        path.reverse()

        return TSPResult(optimal_order=path, optimal_cost=best_cost, applied=True)

def optimise_route_order(
    stop_node_ids:    list[str],
    warehouse_id:     str,
    cost_matrix_dict: dict[tuple[str, str], float],
) -> list[str]:
    """
    Reorder a truck's delivery stops using DP-TSP to minimise travel cost.
    Falls back to input order if N > DP_MAX_NODES.
    """
    if not stop_node_ids:
        return stop_node_ids

    all_nodes = [warehouse_id] + stop_node_ids
    N = len(all_nodes)

    if N > DP_MAX_NODES:
        return stop_node_ids

    INF = float('inf')
    matrix: list[list[float]] = [
        [
            cost_matrix_dict.get((all_nodes[i], all_nodes[j]), INF)
            for j in range(N)
        ]
        for i in range(N)
    ]

    solver = DPTSPSolver()
    result = solver.solve(matrix, N, start_idx=0)

    if not result.applied:
        return stop_node_ids

    reordered = [
        all_nodes[idx]
        for idx in result.optimal_order
        if idx != 0
    ]
    return reordered

def compute_route_cost(
    node_ids:         list[str],
    cost_matrix_dict: dict[tuple[str, str], float],
) -> float:
    """
    Sum the cost of traversing a node sequence.
    Missing edges default to float('inf') — unreachable, not free.
    """
    total = 0.0
    for i in range(len(node_ids) - 1):
        total += cost_matrix_dict.get((node_ids[i], node_ids[i + 1]), float('inf'))
    return total
