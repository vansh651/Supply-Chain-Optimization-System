"""
algorithms — Supply Chain Optimization Algorithm Suite.

This package implements four core algorithms for the optimization pipeline:

1. **Min-Cost Flow** (`min_cost_flow`) — Warehouse-to-order assignment
   via bipartite flow network. O(V·E·log V) using Successive Shortest Paths.

2. **VRP** (`vrp`) — Capacitated Vehicle Routing Problem solver using
   greedy nearest-neighbour + 2-opt + Or-opt local search. O(N² per pass).

3. **DP-TSP** (`dp_tsp`) — Exact Travelling Salesman via Held-Karp bitmask DP.
   O(N²·2^N) time, O(N·2^N) space. Practical for N ≤ 15.

4. **Dijkstra / A*** (`dijkstra`) — Shortest-path routing with haversine
   heuristic. Includes bidirectional A* and Bellman-Ford fallback.

5. **Simulator** (`simulator`) — Demand spike and traffic event generator
   for stress-testing the optimization pipeline.

6. **Optimizer** (`optimizer`) — End-to-end pipeline orchestrator that chains
   all four algorithms into a single optimize() call.

Usage:
    from algorithms.optimizer import optimize
    from algorithms.dijkstra import find_route
    from algorithms.simulator import Simulator
"""

__all__ = [
    "dijkstra",
    "dp_tsp",
    "min_cost_flow",
    "vrp",
    "optimizer",
    "simulator",
]
