"""
algorithms/min_cost_flow.py — Warehouse-to-order assignment via Minimum Cost Flow.

"""

from __future__ import annotations
from dataclasses import dataclass
from typing import Optional
import networkx as nx

from models import Order, Warehouse, OrderStatus
from graph_builder import GraphBuilder
from algorithms.dijkstra import dijkstra_all_pairs

@dataclass
class AssignmentResult:
    assignments:    list[tuple[str, str, float]]
    total_cost:     float
    unassigned:     list[str]
    feasible:       bool

    def to_dict(self) -> dict:
        return {
            "assignments":  [
                {"order_id": oid, "warehouse_id": wid, "cost": round(c, 2)}
                for oid, wid, c in self.assignments
            ],
            "total_cost":   round(self.total_cost, 2),
            "unassigned":   self.unassigned,
            "feasible":     self.feasible,
            "assigned_count": len(self.assignments),
        }

class MinCostFlowSolver:
    """
    Solves the warehouse-to-order assignment problem using min-cost flow.
    """

    _SOURCE = "__SOURCE__"
    _SINK   = "__SINK__"

    # _build_flow_graph use this constant so they agree on what
    # "unreachable" means. Original used 1_000_000 in one place and
    # 9_999 in the other — the mismatch let unreachable paths through.
    _NO_PATH_COST_RAW = 9_999.0
    _COST_SCALE       = 1_000
    _NO_PATH_COST_INT = int(_NO_PATH_COST_RAW * _COST_SCALE)  # 9_999_000

    def __init__(self, graph: GraphBuilder):
        self.graph = graph

    def solve(self, orders: list[Order], warehouses: list[Warehouse]) -> AssignmentResult:
        pending     = [o for o in orders     if o.status == OrderStatus.PENDING]
        stocked_whs = [w for w in warehouses if w.available_stock > 0]

        if not pending:
            return AssignmentResult([], 0.0, [], True)
        if not stocked_whs:
            return AssignmentResult([], 0.0, [o.id for o in pending], False)

        cost_matrix = self._build_cost_matrix(pending, stocked_whs)
        flow_graph  = self._build_flow_graph(pending, stocked_whs, cost_matrix)

        try:
            flow_dict = nx.min_cost_flow(flow_graph)
            return self._extract_assignments(flow_dict, pending, stocked_whs, cost_matrix)
        except nx.NetworkXUnfeasible:
            return self._greedy_fallback(pending, stocked_whs, cost_matrix)

    def _build_cost_matrix(
        self,
        orders:     list[Order],
        warehouses: list[Warehouse],
    ) -> dict[tuple[str, str], float]:
        """
        of 1_000_000.0, matching the cap applied in _build_flow_graph.
        """
        wh_ids = [w.id for w in warehouses]
        dp_ids = [o.destination_id for o in orders]

        path_results = dijkstra_all_pairs(self.graph, wh_ids, dp_ids)

        cost_matrix: dict[tuple[str, str], float] = {}
        for order in orders:
            for wh in warehouses:
                result = path_results.get((wh.id, order.destination_id))
                if result and result.found:
                    raw_cost = result.effective_cost * order.priority_multiplier
                    cost_matrix[(wh.id, order.id)] = min(raw_cost, self._NO_PATH_COST_RAW)
                else:
                    cost_matrix[(wh.id, order.id)] = self._NO_PATH_COST_RAW

        return cost_matrix

    def _build_flow_graph(
        self,
        orders:      list[Order],
        warehouses:  list[Warehouse],
        cost_matrix: dict[tuple[str, str], float],
    ) -> nx.DiGraph:
        G = nx.DiGraph()
        total_demand = sum(o.weight_kg for o in orders)

        G.add_node(self._SOURCE, demand=-total_demand)
        G.add_node(self._SINK,   demand=total_demand)

        for wh in warehouses:
            wh_supply = min(wh.available_stock, total_demand)
            G.add_node(wh.id, demand=0)
            G.add_edge(self._SOURCE, wh.id, capacity=wh_supply, weight=0)

        for order in orders:
            G.add_node(order.id, demand=0)
            G.add_edge(order.id, self._SINK, capacity=order.weight_kg, weight=0)
            for wh in warehouses:
                cost = cost_matrix.get((wh.id, order.id), self._NO_PATH_COST_RAW)
                int_cost = int(cost * self._COST_SCALE)
                G.add_edge(
                    wh.id, order.id,
                    capacity=order.weight_kg,
                    weight=int_cost,
                )

        return G

    def _extract_assignments(
        self,
        flow_dict:   dict,
        orders:      list[Order],
        warehouses:  list[Warehouse],
        cost_matrix: dict[tuple[str, str], float],
    ) -> AssignmentResult:
        assignments: list[tuple[str, str, float]] = []
        assigned_ids: set[str] = set()
        total_cost = 0.0

        order_map = {o.id: o for o in orders}

        for wh in warehouses:
            wh_flows = flow_dict.get(wh.id, {})
            for order_id, flow in wh_flows.items():
                if order_id in order_map and flow > 0:
                    cost = cost_matrix.get((wh.id, order_id), 0.0)
                    assignments.append((order_id, wh.id, cost))
                    assigned_ids.add(order_id)
                    total_cost += cost

        unassigned = [o.id for o in orders if o.id not in assigned_ids]
        return AssignmentResult(
            assignments=assignments,
            total_cost=total_cost,
            unassigned=unassigned,
            feasible=len(unassigned) == 0,
        )

    def _greedy_fallback(
        self,
        orders:      list[Order],
        warehouses:  list[Warehouse],
        cost_matrix: dict[tuple[str, str], float],
    ) -> AssignmentResult:
        priority_order = {"critical": 0, "high": 1, "standard": 2, "low": 3}
        sorted_orders = sorted(orders, key=lambda o: priority_order.get(o.priority.value, 3))

        inventory: dict[str, float] = {w.id: w.available_stock for w in warehouses}
        assignments: list[tuple[str, str, float]] = []
        unassigned: list[str] = []
        total_cost = 0.0

        for order in sorted_orders:
            candidates = [
                (cost_matrix.get((wh.id, order.id), self._NO_PATH_COST_RAW), wh.id)
                for wh in warehouses
                if inventory.get(wh.id, 0) >= order.weight_kg
            ]
            if candidates:
                cost, best_wh_id = min(candidates)
                assignments.append((order.id, best_wh_id, cost))
                inventory[best_wh_id] -= order.weight_kg
                total_cost += cost
            else:
                unassigned.append(order.id)

        return AssignmentResult(
            assignments=assignments,
            total_cost=total_cost,
            unassigned=unassigned,
            feasible=len(unassigned) == 0,
        )
