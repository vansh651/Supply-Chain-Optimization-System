"""
algorithms/vrp.py — Vehicle Routing Problem (VRP) solver.

"""

from __future__ import annotations
import math
from dataclasses import dataclass, field
from typing import Optional
import networkx as nx

from models import Order, Truck, Warehouse, TruckStatus
from graph_builder import GraphBuilder
from algorithms.dijkstra import dijkstra_all_pairs, PathResult

@dataclass
class TruckRoute:
    truck_id:        str
    warehouse_id:    str
    order_ids:       list[str]
    stop_sequence:   list[str]
    coords:          list[dict]
    total_distance:  float
    total_load:      float

    def to_dict(self) -> dict:
        return {
            "truck_id":       self.truck_id,
            "warehouse_id":   self.warehouse_id,
            "order_ids":      self.order_ids,
            "stop_sequence":  self.stop_sequence,
            "coords":         self.coords,
            "total_distance": round(self.total_distance, 2),
            "total_load":     round(self.total_load, 2),
        }

@dataclass
class VRPResult:
    routes:           list[TruckRoute]
    unrouted_orders:  list[str]
    total_distance:   float
    total_trucks_used: int

    def to_dict(self) -> dict:
        return {
            "routes":            [r.to_dict() for r in self.routes],
            "unrouted_orders":   self.unrouted_orders,
            "total_distance":    round(self.total_distance, 2),
            "total_trucks_used": self.total_trucks_used,
        }

@dataclass
class _Stop:
    order_id:   str
    node_id:    str
    weight_kg:  float
    coords:     dict

class VRPSolver:
    """
    Capacitated VRP solver: greedy nearest-neighbour + 2-opt + Or-opt.
    """

    def __init__(self, graph: GraphBuilder):
        self.graph = graph

    def solve(self, orders: list[Order], trucks: list[Truck], warehouse: Warehouse) -> VRPResult:
        if not orders or not trucks:
            return VRPResult([], [o.id for o in orders], 0.0, 0)

        all_node_ids  = [warehouse.id] + [o.destination_id for o in orders]
        path_map      = dijkstra_all_pairs(self.graph, all_node_ids, all_node_ids)
        cost_matrix   = self._extract_cost_matrix(path_map)
        _coords_map   = self._extract_coords(orders, warehouse)

        stops = [
            _Stop(
                order_id=o.id,
                node_id=o.destination_id,
                weight_kg=o.weight_kg,
                coords=o.destination.to_dict(),
            )
            for o in orders
        ]

        routes_stops = self._greedy_assign(stops, trucks, warehouse.id, cost_matrix)

        for truck_id, route_stops in routes_stops.items():
            routes_stops[truck_id] = self._two_opt(route_stops, warehouse.id, cost_matrix)

        for truck_id, route_stops in routes_stops.items():
            routes_stops[truck_id] = self._or_opt(route_stops, warehouse.id, cost_matrix)

        routes_stops = self._rebalance(routes_stops, trucks, warehouse.id, cost_matrix)

        truck_map = {t.id: t for t in trucks}
        routes: list[TruckRoute] = []

        for truck_id, route_stops in routes_stops.items():
            if not route_stops:
                continue
            stop_seq, coords, dist = self._build_full_route(route_stops, warehouse.id, path_map)
            total_load = sum(s.weight_kg for s in route_stops)
            routes.append(TruckRoute(
                truck_id=truck_id,
                warehouse_id=warehouse.id,
                order_ids=[s.order_id for s in route_stops],
                stop_sequence=stop_seq,
                coords=coords,
                total_distance=dist,
                total_load=total_load,
            ))

        assigned_order_ids = {s.order_id for stops in routes_stops.values() for s in stops}
        unrouted = [o.id for o in orders if o.id not in assigned_order_ids]

        total_distance = sum(r.total_distance for r in routes)
        return VRPResult(
            routes=routes,
            unrouted_orders=unrouted,
            total_distance=total_distance,
            total_trucks_used=len(routes),
        )

    # ------------------------------------------------------------------
    # ------------------------------------------------------------------

    def _greedy_assign(
        self,
        stops:        list[_Stop],
        trucks:       list[Truck],
        warehouse_id: str,
        cost_matrix:  dict[tuple[str, str], float],
    ) -> dict[str, list[_Stop]]:
        """

        Original: unvisited.remove(nearest) scans the list linearly to find
        the element, making each removal O(N). With N stops and K trucks this
        was O(N^2 * K) in the greedy phase.

        Fix: maintain a dict {index -> stop} and track positions. After
        picking the nearest stop (by index), swap it with the last entry
        and pop — this is O(1) and preserves the full list for subsequent
        candidate searches. No order guarantees are needed here since we
        rebuild the order via nearest-neighbour anyway.
        """
        # Use a list and a "swap-and-pop" pattern for O(1) removal by index
        unvisited: list[_Stop] = list(stops)
        routes: dict[str, list[_Stop]] = {t.id: [] for t in trucks}
        capacity: dict[str, float]     = {t.id: t.capacity_kg for t in trucks}

        for truck in trucks:
            if not unvisited:
                break

            current_node = warehouse_id
            while unvisited:
                # Find nearest stop that fits — track index for O(1) removal
                best_idx  = -1
                best_cost = float('inf')
                for idx, s in enumerate(unvisited):
                    if s.weight_kg > capacity[truck.id]:
                        continue
                    c = cost_matrix.get((current_node, s.node_id), float('inf'))
                    if c < best_cost:
                        best_cost = c
                        best_idx  = idx

                if best_idx == -1:
                    break  # no fitting stop found

                nearest = unvisited[best_idx]
                # Swap chosen element with the last, then pop last — O(1)
                unvisited[best_idx] = unvisited[-1]
                unvisited.pop()

                routes[truck.id].append(nearest)
                capacity[truck.id] -= nearest.weight_kg
                current_node = nearest.node_id

        return routes

    # ------------------------------------------------------------------
    # Phase 2: 2-opt improvement
    # ------------------------------------------------------------------

    def _two_opt(
        self,
        stops:        list[_Stop],
        warehouse_id: str,
        cost_matrix:  dict[tuple[str, str], float],
    ) -> list[_Stop]:
        if len(stops) <= 2:
            return stops

        best = list(stops)
        improved = True

        while improved:
            improved = False
            best_distance = self._route_cost(best, warehouse_id, cost_matrix)

            for i in range(len(best) - 1):
                for k in range(i + 1, len(best)):
                    new_route = best[:i] + list(reversed(best[i:k + 1])) + best[k + 1:]
                    new_distance = self._route_cost(new_route, warehouse_id, cost_matrix)

                    if new_distance < best_distance - 1e-6:
                        best = new_route
                        best_distance = new_distance
                        improved = True
                        break
                if improved:
                    break

        return best

    # ------------------------------------------------------------------
    # ------------------------------------------------------------------

    def _or_opt(
        self,
        stops:        list[_Stop],
        warehouse_id: str,
        cost_matrix:  dict[tuple[str, str], float],
    ) -> list[_Stop]:
        if len(stops) <= 2:
            return stops

        best = list(stops)
        improved = True

        while improved:
            improved = False
            best_cost = self._route_cost(best, warehouse_id, cost_matrix)

            for L in [3, 2, 1]:
                for i in range(len(best) - L + 1):
                    segment  = best[i:i + L]
                    remaining = best[:i] + best[i + L:]

                    for j in range(len(remaining) + 1):
                        candidate = remaining[:j] + segment + remaining[j:]
                        new_cost  = self._route_cost(candidate, warehouse_id, cost_matrix)
                        if new_cost < best_cost - 1e-6:
                            best = candidate
                            best_cost = new_cost
                            improved = True
                            break
                    if improved:
                        break
                if improved:
                    break

        return best

    # ------------------------------------------------------------------
    # Phase 3: Inter-route rebalancing
    # ------------------------------------------------------------------

    def _rebalance(
        self,
        routes:       dict[str, list[_Stop]],
        trucks:       list[Truck],
        warehouse_id: str,
        cost_matrix:  dict[tuple[str, str], float],
    ) -> dict[str, list[_Stop]]:
        truck_map = {t.id: t for t in trucks}
        loads = {tid: sum(s.weight_kg for s in stops) for tid, stops in routes.items() if stops}

        if len(loads) < 2:
            return routes

        max_tid = max(loads, key=loads.get)
        min_tid = min(loads, key=loads.get)

        if loads[max_tid] == 0 or loads[max_tid] / max(loads[min_tid], 1) < 1.2:
            return routes

        min_truck = truck_map[min_tid]
        cost_before = (
            self._route_cost(routes[max_tid], warehouse_id, cost_matrix) +
            self._route_cost(routes[min_tid], warehouse_id, cost_matrix)
        )

        best_gain: float          = 1e-6
        best_stop: Optional[_Stop] = None
        best_new_heavy: list[_Stop] = []
        best_new_light: list[_Stop] = []

        for stop in routes[max_tid]:
            if stop.weight_kg <= (min_truck.capacity_kg - loads.get(min_tid, 0)):
                new_heavy = [s for s in routes[max_tid] if s.order_id != stop.order_id]
                new_light = routes[min_tid] + [stop]
                cost_after = (
                    self._route_cost(new_heavy, warehouse_id, cost_matrix) +
                    self._route_cost(new_light, warehouse_id, cost_matrix)
                )
                gain = cost_before - cost_after
                if gain > best_gain:
                    best_gain      = gain
                    best_stop      = stop
                    best_new_heavy = new_heavy
                    best_new_light = new_light

        if best_stop is not None:
            routes[max_tid] = best_new_heavy
            routes[min_tid] = best_new_light

        return routes

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _route_cost(
        self,
        stops:        list[_Stop],
        warehouse_id: str,
        cost_matrix:  dict[tuple[str, str], float],
    ) -> float:
        if not stops:
            return 0.0
        nodes = [warehouse_id] + [s.node_id for s in stops] + [warehouse_id]
        return sum(
            cost_matrix.get((nodes[i], nodes[i + 1]), float('inf'))
            for i in range(len(nodes) - 1)
        )

    def _build_full_route(
        self,
        stops:        list[_Stop],
        warehouse_id: str,
        path_map:     dict[tuple[str, str], PathResult],
    ) -> tuple[list[str], list[dict], float]:
        full_node_seq: list[str]  = []
        full_coords:   list[dict] = []
        total_dist = 0.0

        node_seq = [warehouse_id] + [s.node_id for s in stops] + [warehouse_id]

        for i in range(len(node_seq) - 1):
            src, tgt = node_seq[i], node_seq[i + 1]
            result = path_map.get((src, tgt))
            if result and result.found:
                seg_nodes  = result.path   if i == 0 else result.path[1:]
                seg_coords = result.coords if i == 0 else result.coords[1:]
                full_node_seq.extend(seg_nodes)
                full_coords.extend(seg_coords)
                total_dist += result.total_distance

        return full_node_seq, full_coords, total_dist

    def _extract_cost_matrix(
        self,
        path_map: dict[tuple[str, str], PathResult],
    ) -> dict[tuple[str, str], float]:
        return {
            (src, tgt): result.effective_cost
            for (src, tgt), result in path_map.items()
            if result.found
        }

    def _extract_coords(
        self,
        orders:    list[Order],
        warehouse: Warehouse,
    ) -> dict[str, dict]:
        coords = {warehouse.id: warehouse.coords.to_dict()}
        for o in orders:
            coords[o.destination_id] = o.destination.to_dict()
        return coords
