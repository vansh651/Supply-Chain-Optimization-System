"""
algorithms/simulator.py — Demand spike and traffic condition simulator.

"""

from __future__ import annotations
import random
import time
from collections import Counter
from dataclasses import dataclass, field
from typing import Optional

from models import (
    Order, DeliveryPoint, Coordinates,
    OrderPriority, TrafficLevel
)
from graph_builder import GraphBuilder
from state import StateManager

# ---------------------------------------------------------------------------
# Result types
# ---------------------------------------------------------------------------

@dataclass
class DemandSpikeResult:
    """Summary of a demand spike simulation."""
    orders_injected:  int
    order_ids:        list[str]
    total_weight_kg:  float
    affected_dps:     list[str]

    def to_dict(self) -> dict:
        return {
            "orders_injected": self.orders_injected,
            "order_ids":       self.order_ids,
            "total_weight_kg": round(self.total_weight_kg, 2),
            "affected_dps":    self.affected_dps,
            "event":           "demand_spike",
        }

@dataclass
class TrafficEventResult:
    """Summary of a traffic event simulation."""
    edges_affected:  int
    edges_blocked:   int
    severity:        str
    affected_edges:  list[dict]

    def to_dict(self) -> dict:
        return {
            "edges_affected": self.edges_affected,
            "edges_blocked":  self.edges_blocked,
            "severity":       self.severity,
            "affected_edges": self.affected_edges,
            "event":          "traffic_event",
        }

@dataclass
class SimulationResult:
    """Combined result for a full simulation step."""
    demand_spike:    Optional[DemandSpikeResult]
    traffic_event:   Optional[TrafficEventResult]
    timestamp:       float = field(default_factory=time.time)

    def to_dict(self) -> dict:
        return {
            "demand_spike":  self.demand_spike.to_dict()  if self.demand_spike  else None,
            "traffic_event": self.traffic_event.to_dict() if self.traffic_event else None,
            "timestamp":     self.timestamp,
        }

# ---------------------------------------------------------------------------
# Simulator
# ---------------------------------------------------------------------------

class Simulator:
    """
    Stateless simulation engine. Takes a StateManager reference and
    mutates it directly — new orders get added, edge weights change.
    """

    # Priority distribution for spike orders (realistic: mostly standard, some high)
    _PRIORITY_WEIGHTS = {
        OrderPriority.LOW:      10,
        OrderPriority.STANDARD: 50,
        OrderPriority.HIGH:     30,
        OrderPriority.CRITICAL: 10,
    }

    # Severity config as class constant — avoids rebuilding on every call
    _SEVERITY_CONFIG: dict[str, dict] = {
        "minor":    {"fraction": 0.12, "levels": [TrafficLevel.MODERATE] * 10},
        "moderate": {"fraction": 0.30, "levels": [TrafficLevel.MODERATE] * 6 + [TrafficLevel.HEAVY] * 4},
        "major":    {"fraction": 0.50, "levels": [TrafficLevel.HEAVY] * 7 + [TrafficLevel.BLOCKED] * 3},
    }

    def __init__(self, state: StateManager):
        self.state = state
        self._rng  = random.Random()
        self._injected_order_ids: set[str] = set()  # track simulator-injected orders

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def demand_spike(
        self,
        n_orders:      int   = 8,
        min_weight_kg: float = 50.0,
        max_weight_kg: float = 400.0,
        seed:          Optional[int] = None,
    ) -> DemandSpikeResult:
        """
        Inject n_orders new orders at random delivery points.

        is pointless and misleading. Return early with a warning count of 0.
        """
        if seed is not None:
            self._rng.seed(seed)

        delivery_points = list(self.state.delivery_points.values())
        if not delivery_points:
            return DemandSpikeResult(0, [], 0.0, [])

        total_stock = sum(w.available_stock for w in self.state.warehouses.values())
        if total_stock <= 0:
            return DemandSpikeResult(0, [], 0.0, [])

        injected_ids: list[str]  = []
        affected_dps: set[str]   = set()
        total_weight              = 0.0

        # Use a hotspot distribution: pick 2–3 "hot" DPs that get more orders
        hot_dps = self._rng.sample(
            delivery_points,
            min(3, len(delivery_points))
        )

        for _ in range(n_orders):
            if self._rng.random() < 0.6 and hot_dps:
                dp = self._rng.choice(hot_dps)
            else:
                dp = self._rng.choice(delivery_points)

            weight = round(self._rng.uniform(min_weight_kg, max_weight_kg), 1)
            priority = self._rng.choices(
                list(self._PRIORITY_WEIGHTS.keys()),
                weights=list(self._PRIORITY_WEIGHTS.values()),
                k=1
            )[0]

            order = Order(
                destination=dp.coords,
                weight_kg=weight,
                destination_id=dp.id,
                priority=priority,
            )
            self.state.add_order(order)
            injected_ids.append(order.id)
            self._injected_order_ids.add(order.id)
            affected_dps.add(dp.id)
            total_weight += weight

        return DemandSpikeResult(
            orders_injected=n_orders,
            order_ids=injected_ids,
            total_weight_kg=total_weight,
            affected_dps=list(affected_dps),
        )

    def traffic_event(
        self,
        severity: str = "moderate",
        seed:     Optional[int] = None,
    ) -> TrafficEventResult:
        """
        Apply traffic conditions to road edges.

        the dict on every call.
        """
        if seed is not None:
            self._rng.seed(seed)

        graph = self.state.graph
        all_edges = list(graph.G.edges())

        if not all_edges:
            return TrafficEventResult(0, 0, severity, [])

        config = self._SEVERITY_CONFIG.get(severity, self._SEVERITY_CONFIG["moderate"])

        n_affected = max(1, int(len(all_edges) * config["fraction"]))
        affected_edges_sample = self._rng.sample(all_edges, min(n_affected, len(all_edges)))

        affected_summary: list[dict] = []
        blocked_count = 0

        for src, tgt in affected_edges_sample:
            level = self._rng.choice(config["levels"])
            try:
                graph.set_traffic(src, tgt, level)
                affected_summary.append({
                    "source":        src,
                    "target":        tgt,
                    "traffic_level": level.value,
                })
                if level == TrafficLevel.BLOCKED:
                    blocked_count += 1
            except KeyError:
                pass

        return TrafficEventResult(
            edges_affected=len(affected_summary),
            edges_blocked=blocked_count,
            severity=severity,
            affected_edges=affected_summary,
        )

    def full_simulation(
        self,
        n_orders:      int  = 8,
        severity:      str  = "moderate",
        include_spike: bool = True,
        include_traffic: bool = True,
        seed:          Optional[int] = None,
    ) -> SimulationResult:
        """
        Run both demand spike and traffic event together.

        each sub-call so that reproducibility is guaranteed for both, but they
        don't share the same RNG state (which previously caused the second call
        to be non-deterministic relative to the seed).
        """
        if seed is not None:
            spike_seed   = seed
            traffic_seed = seed + 1000  # deterministic but distinct
        else:
            spike_seed = traffic_seed = None

        spike_result   = self.demand_spike(n_orders=n_orders, seed=spike_seed)   if include_spike   else None
        traffic_result = self.traffic_event(severity=severity, seed=traffic_seed) if include_traffic else None

        return SimulationResult(
            demand_spike=spike_result,
            traffic_event=traffic_result,
        )

    def reset_traffic(self) -> int:
        """Reset all road edges to CLEAR. Returns the number of edges reset."""
        graph = self.state.graph
        n = graph.edge_count
        graph.reset_all_traffic()
        return n

    def clear_pending_orders(self) -> int:
        """
        Remove all PENDING orders.
        Returns the number of orders removed.
        """
        from models import OrderStatus
        pending_ids = [
            oid for oid, o in self.state.orders.items()
            if o.status == OrderStatus.PENDING
        ]
        for oid in pending_ids:
            del self.state.orders[oid]
        self._injected_order_ids -= set(pending_ids)
        return len(pending_ids)

    def clear_injected_orders(self) -> int:
        """
        NEW: Remove only simulator-injected PENDING orders (not user-placed ones).
        Useful for selective resets in demo flows.
        """
        from models import OrderStatus
        to_remove = [
            oid for oid in self._injected_order_ids
            if oid in self.state.orders and self.state.orders[oid].status == OrderStatus.PENDING
        ]
        for oid in to_remove:
            del self.state.orders[oid]
        self._injected_order_ids -= set(to_remove)
        return len(to_remove)

    def get_traffic_summary(self) -> dict:
        """
        Return a summary of current traffic conditions across the network.

        even when unexpected traffic values appear in the graph.
        """
        counts: Counter = Counter()
        for _, _, data in self.state.graph.G.edges(data=True):
            level = data.get('traffic', TrafficLevel.CLEAR.value)
            counts[level] += 1

        # Ensure all standard levels appear in output (even if count=0)
        result = {level.value: counts.get(level.value, 0) for level in TrafficLevel}

        return {
            "edge_counts_by_traffic": result,
            "total_edges": self.state.graph.edge_count,
            "congestion_ratio": round(
                (result.get("moderate", 0) + result.get("heavy", 0) + result.get("blocked", 0))
                / max(self.state.graph.edge_count, 1),
                3
            ),
        }
