"""
algorithms/dijkstra.py — Shortest-path algorithms for the supply chain road network.

"""

from __future__ import annotations
import math
import heapq
from dataclasses import dataclass, field
from typing import Optional
import networkx as nx

from graph_builder import GraphBuilder

@dataclass
class PathResult:
    source:           str
    target:           str
    path:             list[str]
    coords:           list[dict]
    total_distance:   float
    effective_cost:   float
    algorithm:        str
    found:            bool = True

    @classmethod
    def not_found(cls, source: str, target: str, algorithm: str) -> "PathResult":
        return cls(
            source=source, target=target, path=[], coords=[],
            total_distance=0.0, effective_cost=float('inf'),
            algorithm=algorithm, found=False
        )

    def to_dict(self) -> dict:
        return {
            "source":         self.source,
            "target":         self.target,
            "path":           self.path,
            "coords":         self.coords,
            "total_distance": round(self.total_distance, 2),
            "effective_cost": round(self.effective_cost, 2),
            "algorithm":      self.algorithm,
            "found":          self.found,
            "hop_count":      len(self.path) - 1 if self.found else 0,
        }

def _build_coords(graph: GraphBuilder, path: list[str]) -> list[dict]:
    coords = []
    for node_id in path:
        c = graph.get_node_coords(node_id)
        if c:
            coords.append(c.to_dict())
    return coords

def _path_distance(graph: GraphBuilder, path: list[str]) -> tuple[float, float]:
    total_dist = 0.0
    total_cost = 0.0
    for i in range(len(path) - 1):
        u, v = path[i], path[i + 1]
        edge_data = graph.G[u][v]
        dist = edge_data.get('distance')
        if dist is None:
            raise KeyError(
                f"Edge ({u!r}, {v!r}) is missing the 'distance' attribute. "
                "The graph may have been mutated after path computation."
            )
        total_dist += dist
        total_cost += edge_data.get('weight', float('inf'))
    return total_dist, total_cost

def _haversine_heuristic(graph: GraphBuilder, node: str, goal: str) -> float:
    """
    Admissible haversine heuristic for A*. Never overestimates — road
    distance >= straight-line distance, so optimality is guaranteed.
    """
    a = graph.get_node_coords(node)
    b = graph.get_node_coords(goal)
    if not a or not b:
        return 0.0
    R = 6371.0
    phi1, phi2 = math.radians(a.lat), math.radians(b.lat)
    dphi = math.radians(b.lat - a.lat)
    dlng = math.radians(b.lng - a.lng)
    x = math.sin(dphi / 2) ** 2 + math.cos(phi1) * math.cos(phi2) * math.sin(dlng / 2) ** 2
    return R * 2 * math.atan2(math.sqrt(x), math.sqrt(1 - x))

# ---------------------------------------------------------------------------
# Dijkstra
# ---------------------------------------------------------------------------

def dijkstra(graph: GraphBuilder, source: str, target: str) -> PathResult:
    if not graph.node_exists(source):
        raise ValueError(f"Source node '{source}' not found in graph")
    if not graph.node_exists(target):
        raise ValueError(f"Target node '{target}' not found in graph")

    try:
        path = nx.dijkstra_path(graph.G, source, target, weight='weight')
        total_dist, effective_cost = _path_distance(graph, path)
        coords = _build_coords(graph, path)
        return PathResult(
            source=source, target=target,
            path=path, coords=coords,
            total_distance=total_dist,
            effective_cost=effective_cost,
            algorithm="dijkstra",
        )
    except nx.NetworkXNoPath:
        return PathResult.not_found(source, target, "dijkstra")
    except nx.NodeNotFound:
        return PathResult.not_found(source, target, "dijkstra")

def dijkstra_all_pairs(
    graph: GraphBuilder,
    sources: list[str],
    targets: list[str],
) -> dict[tuple[str, str], PathResult]:
    """
    Compute shortest paths from every source to every target.
    One nx.single_source_dijkstra pass per source → O(S*(V+E)*log V).
    """
    results: dict[tuple[str, str], PathResult] = {}
    for src in sources:
        try:
            _lengths, paths = nx.single_source_dijkstra(graph.G, src, weight='weight')
            for tgt in targets:
                if tgt == src:
                    continue
                if tgt in paths:
                    path = paths[tgt]
                    dist, cost = _path_distance(graph, path)
                    results[(src, tgt)] = PathResult(
                        source=src, target=tgt,
                        path=path, coords=_build_coords(graph, path),
                        total_distance=dist, effective_cost=cost,
                        algorithm="dijkstra",
                    )
                else:
                    results[(src, tgt)] = PathResult.not_found(src, tgt, "dijkstra")
        except nx.NodeNotFound:
            for tgt in targets:
                results[(src, tgt)] = PathResult.not_found(src, tgt, "dijkstra")
    return results

# ---------------------------------------------------------------------------
# A*
# ---------------------------------------------------------------------------

def astar(graph: GraphBuilder, source: str, target: str) -> PathResult:
    if not graph.node_exists(source):
        raise ValueError(f"Source node '{source}' not found in graph")
    if not graph.node_exists(target):
        raise ValueError(f"Target node '{target}' not found in graph")

    counter = 0
    open_set: list[tuple[float, int, str]] = []
    heapq.heappush(open_set, (0.0, counter, source))

    came_from:  dict[str, str]   = {}
    g_score:    dict[str, float] = {source: 0.0}
    closed_set: set[str]         = set()

    while open_set:
        _, _, current = heapq.heappop(open_set)

        if current in closed_set:
            continue
        closed_set.add(current)

        if current == target:
            path = []
            node = target
            while node in came_from:
                path.append(node)
                node = came_from[node]
            path.append(source)
            path.reverse()
            total_dist, effective_cost = _path_distance(graph, path)
            return PathResult(
                source=source, target=target,
                path=path, coords=_build_coords(graph, path),
                total_distance=total_dist,
                effective_cost=effective_cost,
                algorithm="astar",
            )

        for neighbor in graph.G.successors(current):
            if neighbor in closed_set:
                continue
            edge_weight = graph.G[current][neighbor].get('weight', float('inf'))
            tentative_g = g_score[current] + edge_weight
            if tentative_g < g_score.get(neighbor, float('inf')):
                came_from[neighbor] = current
                g_score[neighbor] = tentative_g
                h = _haversine_heuristic(graph, neighbor, target)
                f = tentative_g + h
                counter += 1
                heapq.heappush(open_set, (f, counter, neighbor))

    return PathResult.not_found(source, target, "astar")

def _bellman_ford(graph: GraphBuilder, source: str, target: str) -> PathResult:
    """O(VE) fallback for graphs with negative edge weights."""
    try:
        path = nx.bellman_ford_path(graph.G, source, target, weight='weight')
        total_dist, effective_cost = _path_distance(graph, path)
        return PathResult(
            source=source, target=target,
            path=path, coords=_build_coords(graph, path),
            total_distance=total_dist,
            effective_cost=effective_cost,
            algorithm="bellman_ford",
        )
    except (nx.NetworkXNoPath, nx.NodeNotFound, nx.NetworkXUnbounded):
        return PathResult.not_found(source, target, "bellman_ford")

# ---------------------------------------------------------------------------
# ---------------------------------------------------------------------------

def bidirectional_astar(graph: GraphBuilder, source: str, target: str) -> PathResult:
    """
    Bidirectional A* with two correctness fixes over the original:

        Original: stop when min_f + min_b >= mu   ← WRONG on weighted graphs
        Fixed:    stop when min_f >= mu AND min_b >= mu

        Rationale: once a frontier's minimum f-score reaches mu, every node
        remaining on that frontier already costs at least mu. Expanding any
        of them cannot produce a path cheaper than mu — so that frontier is
        exhausted. We need BOTH frontiers exhausted before stopping.

        came_from_b[v] = u means the backward search reached v by expanding u.
        To walk from meeting_node toward target, follow came_from_b forward:
            meeting_node -> came_from_b[meeting_node] -> ... -> target
        The original code reversed this, producing target→meeting instead of
        meeting→target, and broke on directed graphs.
    """
    if not graph.node_exists(source):
        raise ValueError(f"Source node '{source}' not found in graph")
    if not graph.node_exists(target):
        raise ValueError(f"Target node '{target}' not found in graph")

    if source == target:
        coords = _build_coords(graph, [source])
        return PathResult(source=source, target=target, path=[source], coords=coords,
                          total_distance=0.0, effective_cost=0.0, algorithm="bidir_astar")

    INF = float('inf')
    counter = 0

    # Forward frontier
    open_f: list[tuple[float, int, str]] = []
    g_f: dict[str, float] = {source: 0.0}
    came_from_f: dict[str, str] = {}
    closed_f: set[str] = set()
    heapq.heappush(open_f, (0.0, counter, source))

    # Backward frontier (searching predecessors, since graph is directed)
    open_b: list[tuple[float, int, str]] = []
    g_b: dict[str, float] = {target: 0.0}
    came_from_b: dict[str, str] = {}  # came_from_b[v] = u: backward search expanded u, relaxed v
    closed_b: set[str] = set()
    counter += 1
    heapq.heappush(open_b, (0.0, counter, target))

    mu = INF
    meeting: str | None = None

    def _reconstruct(node: str) -> list[str]:
        # Forward half: backtrack came_from_f to source, then reverse
        path_fwd: list[str] = []
        cur = node
        while cur in came_from_f:
            path_fwd.append(cur)
            cur = came_from_f[cur]
        path_fwd.append(source)
        path_fwd.reverse()  # [source, ..., node]

        # came_from_b[v]=u means backward search went u->v, so following it
        # from meeting_node gives us the path toward target.
        path_bwd: list[str] = []
        cur = node
        seen: set[str] = {node}
        while cur in came_from_b and came_from_b[cur] not in seen:
            cur = came_from_b[cur]
            seen.add(cur)
            path_bwd.append(cur)
        # path_bwd = [node_after_meeting, ..., target]

        return path_fwd + path_bwd

    def _expand_forward() -> None:
        nonlocal counter, mu, meeting
        if not open_f:
            return
        _, _, u = heapq.heappop(open_f)
        if u in closed_f:
            return
        closed_f.add(u)
        for v in graph.G.successors(u):
            w = graph.G[u][v].get('weight', INF)
            ng = g_f[u] + w
            if ng < g_f.get(v, INF):
                g_f[v] = ng
                came_from_f[v] = u
                h = _haversine_heuristic(graph, v, target)
                counter += 1
                heapq.heappush(open_f, (ng + h, counter, v))
                if v in g_b:
                    candidate = ng + g_b[v]
                    if candidate < mu:
                        mu = candidate
                        meeting = v

    def _expand_backward() -> None:
        nonlocal counter, mu, meeting
        if not open_b:
            return
        _, _, u = heapq.heappop(open_b)
        if u in closed_b:
            return
        closed_b.add(u)
        for v in graph.G.predecessors(u):
            w = graph.G[v][u].get('weight', INF)
            ng = g_b[u] + w
            if ng < g_b.get(v, INF):
                g_b[v] = ng
                came_from_b[v] = u
                h = _haversine_heuristic(graph, v, source)
                counter += 1
                heapq.heappush(open_b, (ng + h, counter, v))
                if v in g_f:
                    candidate = g_f[v] + ng
                    if candidate < mu:
                        mu = candidate
                        meeting = v

    while open_f and open_b:
        min_f = open_f[0][0]
        min_b = open_b[0][0]

        if min_f >= mu and min_b >= mu:
            break

        if min_f <= min_b:
            _expand_forward()
        else:
            _expand_backward()

    if meeting is None:
        return PathResult.not_found(source, target, "bidir_astar")

    path = _reconstruct(meeting)
    total_dist, effective_cost = _path_distance(graph, path)
    return PathResult(
        source=source, target=target,
        path=path, coords=_build_coords(graph, path),
        total_distance=total_dist, effective_cost=effective_cost,
        algorithm="bidir_astar",
    )

def find_route(
    graph: GraphBuilder,
    source: str,
    target: str,
    algorithm: str = "astar",
) -> PathResult:
    """
    Public entry point.

    flag, instead of the O(E) full scan that ran on every single call.
    """
    import warnings
    if graph.has_negative_weights:
        warnings.warn(
            "Negative edge weights detected. Falling back to Bellman-Ford.",
            stacklevel=2,
        )
        return _bellman_ford(graph, source, target)

    if algorithm == "dijkstra":
        return dijkstra(graph, source, target)
    if algorithm in ("bidir_astar", "auto"):
        return bidirectional_astar(graph, source, target)
    return astar(graph, source, target)
