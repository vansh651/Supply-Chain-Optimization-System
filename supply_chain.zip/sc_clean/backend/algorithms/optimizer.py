"""
algorithms/optimizer.py — End-to-end optimization pipeline orchestrator.

"""

from __future__ import annotations
import logging
import time
from dataclasses import dataclass, field

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(name)s — %(message)s",
)
log = logging.getLogger(__name__)

from models import OrderStatus, TruckStatus
from state import StateManager
from algorithms.min_cost_flow import MinCostFlowSolver, AssignmentResult
from algorithms.vrp import VRPSolver, VRPResult
from algorithms.dp_tsp import optimise_route_order, compute_route_cost
from algorithms.dijkstra import dijkstra_all_pairs

@dataclass
class OptimizationResult:
    assignment:        AssignmentResult
    vrp_results:       list[VRPResult]
    total_distance:    float
    total_cost:        float
    trucks_dispatched: int
    orders_routed:     int
    unrouted_orders:   list[str]
    duration_ms:       float
    stage_times_ms:    dict[str, float] = field(default_factory=dict)
    timestamp:         float = field(default_factory=time.time)

    def to_dict(self) -> dict:
        return {
            "assignment":        self.assignment.to_dict(),
            "vrp_results":       [v.to_dict() for v in self.vrp_results],
            "total_distance":    round(self.total_distance, 2),
            "total_cost":        round(self.total_cost, 2),
            "trucks_dispatched": self.trucks_dispatched,
            "orders_routed":     self.orders_routed,
            "unrouted_orders":   self.unrouted_orders,
            "duration_ms":       round(self.duration_ms, 1),
            "stage_times_ms":    {k: round(v, 1) for k, v in self.stage_times_ms.items()},
            "timestamp":         self.timestamp,
        }

def optimize(state: StateManager) -> OptimizationResult:
    """
    Run the full 4-stage optimization pipeline.

    entire mutation block, preventing interleaved writes from concurrent calls.

    state.get_all_pairs_costs() and reused across MCF, VRP, and DP-TSP
    stages instead of being recomputed independently each time.
    """
    t_start = time.time()

    pending_orders = state.get_pending_orders()
    warehouses     = list(state.warehouses.values())
    idle_trucks    = state.get_idle_trucks()

    if not pending_orders:
        return OptimizationResult(
            assignment=AssignmentResult([], 0.0, [], True),
            vrp_results=[],
            total_distance=0.0, total_cost=0.0,
            trucks_dispatched=0, orders_routed=0, unrouted_orders=[],
            duration_ms=(time.time() - t_start) * 1000,
            stage_times_ms={"mcf": 0.0, "vrp": 0.0, "tsp": 0.0, "update": 0.0},
        )

    # ----------------------------------------------------------------
    # Stage 1: Min-Cost Flow — assign orders to warehouses
    # ----------------------------------------------------------------
    t0 = time.time()
    mcf_solver = MinCostFlowSolver(state.graph)
    assignment = mcf_solver.solve(pending_orders, warehouses)
    t_mcf = (time.time() - t0) * 1000

    # Apply warehouse assignments to orders (status: PENDING → ASSIGNED)
    wh_to_orders: dict[str, list] = {}
    for order_id, wh_id, _cost in assignment.assignments:
        order = state.get_order(order_id)
        if order:
            order.assign_warehouse(wh_id)
            wh_to_orders.setdefault(wh_id, []).append(order)

    # ----------------------------------------------------------------
    # Stage 2: VRP — per warehouse, assign orders to trucks
    # ----------------------------------------------------------------
    t1 = time.time()
    vrp_solver  = VRPSolver(state.graph)
    vrp_results = []
    all_routes  = []

    for wh_id, wh_orders in wh_to_orders.items():
        warehouse = state.get_warehouse(wh_id)
        if not warehouse:
            continue

        wh_trucks = [t for t in idle_trucks if t.warehouse_id == wh_id]
        if not wh_trucks:
            wh_trucks = state.get_trucks_for_warehouse(wh_id)[:1]
        if not wh_trucks:
            continue

        vrp_result = vrp_solver.solve(wh_orders, wh_trucks, warehouse)
        vrp_results.append(vrp_result)
        all_routes.extend(vrp_result.routes)

    t_vrp = (time.time() - t1) * 1000

    # ----------------------------------------------------------------
    # Stage 3: DP-TSP — refine each truck's stop order
    # ----------------------------------------------------------------
    t2 = time.time()
    for route in all_routes:
        if len(route.order_ids) <= 1:
            continue

        stop_node_ids = []
        for order_id in route.order_ids:
            order = state.get_order(order_id)
            if order:
                stop_node_ids.append(order.destination_id)

        if not stop_node_ids:
            continue

        all_nodes = [route.warehouse_id] + stop_node_ids

        path_map = state.get_all_pairs_costs(all_nodes, all_nodes)
        cost_dict = {
            (src, tgt): res.effective_cost
            for (src, tgt), res in path_map.items()
            if res.found
        }

        full_before = [route.warehouse_id] + stop_node_ids + [route.warehouse_id]
        cost_before = compute_route_cost(full_before, cost_dict)

        optimised_stops = optimise_route_order(stop_node_ids, route.warehouse_id, cost_dict)

        full_after  = [route.warehouse_id] + optimised_stops + [route.warehouse_id]
        cost_after  = compute_route_cost(full_after, cost_dict)

        if cost_after < cost_before - 0.5:
            node_to_order = {
                state.get_order(oid).destination_id: oid
                for oid in route.order_ids
                if state.get_order(oid)
            }
            route.order_ids    = [node_to_order[n] for n in optimised_stops if n in node_to_order]
            route.stop_sequence = full_after[:-1]

    t_tsp = (time.time() - t2) * 1000

    # ----------------------------------------------------------------
    # Stage 4: Persist assignments → StateManager
    # ----------------------------------------------------------------
    t3 = time.time()
    trucks_dispatched = 0
    orders_routed     = 0

    # Concurrent optimize() calls cannot interleave order/truck/inventory writes.
    with state._lock:
        for route in all_routes:
            truck = state.get_truck(route.truck_id)
            wh    = state.get_warehouse(route.warehouse_id)
            if not truck or not wh:
                continue

            total_weight = 0.0
            for order_id in route.order_ids:
                order = state.get_order(order_id)
                if order:
                    order.assign_truck(route.truck_id)
                    total_weight += order.weight_kg
                    orders_routed += 1

            truck.current_load    = total_weight
            truck.assigned_orders = route.order_ids
            truck.dispatch(
                route=route.stop_sequence,
                route_coords=route.coords,
                distance_km=route.total_distance,
            )
            trucks_dispatched += 1

            try:
                wh.consume(total_weight)
                state.graph.update_inventory(wh.id, wh.inventory)
            except ValueError:
                log.warning(
                    "Warehouse '%s' insufficient stock (%.1f kg) for route total %.1f kg. "
                    "Reverting %d orders to PENDING.",
                    wh.id, wh.inventory, total_weight, len(route.order_ids)
                )
                for order_id in route.order_ids:
                    order = state.get_order(order_id)
                    if order:
                        order.status       = OrderStatus.PENDING
                        order.warehouse_id = None
                        order.truck_id     = None
                truck.assigned_orders = []
                truck.current_load    = 0.0
                truck.status          = TruckStatus.IDLE
                trucks_dispatched    -= 1
                orders_routed        -= len(route.order_ids)

    routed_ids = {oid for route in all_routes for oid in route.order_ids}
    unrouted = [
        oid for oid in (
            assignment.unassigned +
            [oid for vrp_r in vrp_results for oid in vrp_r.unrouted_orders]
        )
        if oid not in routed_ids
    ]
    unrouted = list(dict.fromkeys(unrouted))  # deduplicate, preserve order

    total_distance = sum(r.total_distance for r in all_routes)
    state.increment_optimization_count()

    return OptimizationResult(
        assignment=assignment,
        vrp_results=vrp_results,
        total_distance=total_distance,
        total_cost=assignment.total_cost,
        trucks_dispatched=trucks_dispatched,
        orders_routed=orders_routed,
        unrouted_orders=unrouted,
        duration_ms=(time.time() - t_start) * 1000,
        stage_times_ms={
            "mcf":    t_mcf,
            "vrp":    t_vrp,
            "tsp":    t_tsp,
            "update": (time.time() - t3) * 1000,
        },
    )
