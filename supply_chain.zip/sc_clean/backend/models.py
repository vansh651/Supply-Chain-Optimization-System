"""
models.py — Core domain models for the Supply Chain Optimization Platform.

All entities are represented as Python dataclasses with validation,
serialization helpers, and clear type annotations.
"""

from __future__ import annotations
from dataclasses import dataclass, field
from enum import Enum
from typing import Optional
import uuid
import time

# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------

class NodeType(str, Enum):
    WAREHOUSE    = "warehouse"
    DELIVERY     = "delivery"
    CROSSDOCK    = "crossdock"   # intermediate transfer hub

class OrderStatus(str, Enum):
    PENDING      = "pending"
    ASSIGNED     = "assigned"
    IN_TRANSIT   = "in_transit"
    DELIVERED    = "delivered"
    FAILED       = "failed"

class OrderPriority(str, Enum):
    LOW          = "low"
    STANDARD     = "standard"
    HIGH         = "high"
    CRITICAL     = "critical"

class TruckStatus(str, Enum):
    IDLE         = "idle"
    LOADING      = "loading"
    EN_ROUTE     = "en_route"
    RETURNING    = "returning"

class TrafficLevel(str, Enum):
    CLEAR        = "clear"       # multiplier ~1.0
    MODERATE     = "moderate"    # multiplier ~1.4
    HEAVY        = "heavy"       # multiplier ~2.0
    BLOCKED      = "blocked"     # multiplier ~5.0

# ---------------------------------------------------------------------------
# Value Objects
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class Coordinates:
    """Immutable lat/lng pair. frozen=True makes it hashable for use as dict keys."""
    lat: float
    lng: float

    def __post_init__(self):
        if not (-90 <= self.lat <= 90):
            raise ValueError(f"Latitude {self.lat} out of range [-90, 90]")
        if not (-180 <= self.lng <= 180):
            raise ValueError(f"Longitude {self.lng} out of range [-180, 180]")

    def to_dict(self) -> dict:
        return {"lat": self.lat, "lng": self.lng}

    def to_tuple(self) -> tuple[float, float]:
        """Return (lat, lng) tuple — used by geopy distance calculations."""
        return (self.lat, self.lng)

# ---------------------------------------------------------------------------
# Core Entities
# ---------------------------------------------------------------------------

@dataclass
class Warehouse:
    """
    A warehouse is a supply node in the graph.
    It holds inventory and dispatches trucks.
    """
    name:         str
    coords:       Coordinates
    capacity_kg:  float              = 1000.0   # max storage in kg
    inventory:    float              = 500.0    # current stock in kg
    id:           str                = field(default_factory=lambda: str(uuid.uuid4())[:8])
    created_at:   float              = field(default_factory=time.time)

    def __post_init__(self):
        if self.capacity_kg <= 0:
            raise ValueError("Warehouse capacity must be positive")
        if not (0 <= self.inventory <= self.capacity_kg):
            raise ValueError("Inventory must be between 0 and capacity")

    @property
    def utilization(self) -> float:
        """Returns inventory utilization as a 0–1 float."""
        return self.inventory / self.capacity_kg if self.capacity_kg > 0 else 0.0

    @property
    def available_stock(self) -> float:
        return self.inventory

    def consume(self, amount_kg: float) -> None:
        """Reduce inventory when an order is dispatched."""
        if amount_kg > self.inventory:
            raise ValueError(f"Insufficient inventory: need {amount_kg}kg, have {self.inventory}kg")
        self.inventory -= amount_kg

    def restock(self, amount_kg: float) -> None:
        """Add inventory up to capacity."""
        self.inventory = min(self.capacity_kg, self.inventory + amount_kg)

    def to_dict(self) -> dict:
        return {
            "id":            self.id,
            "name":          self.name,
            "type":          NodeType.WAREHOUSE.value,
            "coords":        self.coords.to_dict(),
            "capacity_kg":   self.capacity_kg,
            "inventory":     self.inventory,
            "utilization":   round(self.utilization, 3),
            "created_at":    self.created_at,
        }

@dataclass
class DeliveryPoint:
    """
    A delivery destination — a demand node in the graph.
    Can represent a customer, store, or distribution hub.
    """
    name:       str
    coords:     Coordinates
    demand_kg:  float              = 0.0
    id:         str                = field(default_factory=lambda: str(uuid.uuid4())[:8])
    created_at: float              = field(default_factory=time.time)

    def to_dict(self) -> dict:
        return {
            "id":         self.id,
            "name":       self.name,
            "type":       NodeType.DELIVERY.value,
            "coords":     self.coords.to_dict(),
            "demand_kg":  self.demand_kg,
            "created_at": self.created_at,
        }

@dataclass
class Order:
    """
    A delivery order links a warehouse (supply) to a delivery point (demand).
    Central to both the Min Cost Flow and VRP algorithms.
    """
    destination:    Coordinates
    weight_kg:      float
    destination_id: str
    priority:       OrderPriority       = OrderPriority.STANDARD
    status:         OrderStatus         = OrderStatus.PENDING
    warehouse_id:   Optional[str]       = None    # assigned after min-cost-flow
    truck_id:       Optional[str]       = None    # assigned after VRP
    id:             str                 = field(default_factory=lambda: str(uuid.uuid4())[:8])
    created_at:     float               = field(default_factory=time.time)
    delivered_at:   Optional[float]     = None

    def __post_init__(self):
        if self.weight_kg <= 0:
            raise ValueError("Order weight must be positive")

    @property
    def age_seconds(self) -> float:
        return time.time() - self.created_at

    @property
    def priority_multiplier(self) -> float:
        """Higher priority orders get lower effective cost — used in min-cost flow."""
        return {
            OrderPriority.LOW:      1.5,
            OrderPriority.STANDARD: 1.0,
            OrderPriority.HIGH:     0.6,
            OrderPriority.CRITICAL: 0.3,
        }[self.priority]

    def assign_warehouse(self, warehouse_id: str) -> None:
        self.warehouse_id = warehouse_id
        self.status = OrderStatus.ASSIGNED

    def assign_truck(self, truck_id: str) -> None:
        self.truck_id = truck_id
        self.status = OrderStatus.IN_TRANSIT

    def mark_delivered(self) -> None:
        self.status = OrderStatus.DELIVERED
        self.delivered_at = time.time()

    def to_dict(self) -> dict:
        return {
            "id":             self.id,
            "destination":    self.destination.to_dict(),
            "destination_id": self.destination_id,
            "weight_kg":      self.weight_kg,
            "priority":       self.priority.value,
            "status":         self.status.value,
            "warehouse_id":   self.warehouse_id,
            "truck_id":       self.truck_id,
            "created_at":     self.created_at,
            "delivered_at":   self.delivered_at,
            "age_seconds":    round(self.age_seconds, 1),
        }

@dataclass
class Truck:
    """
    A truck is a vehicle dispatched from a warehouse.
    It carries a list of orders and follows a computed route.
    """
    warehouse_id:   str
    name:           str
    capacity_kg:    float              = 1000.0
    speed_kmh:      float              = 60.0
    status:         TruckStatus        = TruckStatus.IDLE
    current_load:   float              = 0.0
    assigned_orders: list[str]         = field(default_factory=list)   # list of order IDs
    route:          list[str]          = field(default_factory=list)   # list of node IDs
    route_coords:   list[dict]         = field(default_factory=list)   # [{lat, lng}, ...]
    total_distance: float              = 0.0   # km
    id:             str                = field(default_factory=lambda: str(uuid.uuid4())[:8])
    created_at:     float              = field(default_factory=time.time)

    def __post_init__(self):
        if self.capacity_kg <= 0:
            raise ValueError("Truck capacity must be positive")
        if self.speed_kmh <= 0:
            raise ValueError("Truck speed must be positive")

    @property
    def available_capacity(self) -> float:
        return self.capacity_kg - self.current_load

    @property
    def load_factor(self) -> float:
        return self.current_load / self.capacity_kg if self.capacity_kg > 0 else 0.0

    @property
    def estimated_duration_hours(self) -> float:
        return self.total_distance / self.speed_kmh if self.speed_kmh > 0 else 0.0

    def can_accept(self, weight_kg: float) -> bool:
        return self.available_capacity >= weight_kg

    def load_order(self, order_id: str, weight_kg: float) -> None:
        if not self.can_accept(weight_kg):
            raise ValueError(f"Truck {self.id} cannot accept {weight_kg}kg — only {self.available_capacity}kg available")
        self.assigned_orders.append(order_id)
        self.current_load += weight_kg
        self.status = TruckStatus.LOADING

    def dispatch(self, route: list[str], route_coords: list[dict], distance_km: float) -> None:
        """Finalize route and set truck to en-route."""
        self.route = route
        self.route_coords = route_coords
        self.total_distance = distance_km
        self.status = TruckStatus.EN_ROUTE

    def reset(self) -> None:
        """Return truck to idle state after delivery."""
        self.assigned_orders = []
        self.route = []
        self.route_coords = []
        self.current_load = 0.0
        self.total_distance = 0.0
        self.status = TruckStatus.IDLE

    def to_dict(self) -> dict:
        return {
            "id":                       self.id,
            "name":                     self.name,
            "warehouse_id":             self.warehouse_id,
            "type":                     "truck",
            "capacity_kg":              self.capacity_kg,
            "current_load":             self.current_load,
            "available_capacity":       self.available_capacity,
            "load_factor":              round(self.load_factor, 3),
            "speed_kmh":                self.speed_kmh,
            "status":                   self.status.value,
            "assigned_orders":          self.assigned_orders,
            "route":                    self.route,
            "route_coords":             self.route_coords,
            "total_distance":           round(self.total_distance, 2),
            "estimated_duration_hours": round(self.estimated_duration_hours, 2),
            "created_at":               self.created_at,
        }

@dataclass
class RoadEdge:
    """
    Represents a directed road segment between two nodes in the graph.
    Tracks base distance and a live traffic multiplier.
    """
    source_id:          str
    target_id:          str
    distance_km:        float
    traffic_level:      TrafficLevel    = TrafficLevel.CLEAR
    traffic_multiplier: float           = 1.0
    is_blocked:         bool            = False

    @property
    def effective_cost(self) -> float:
        """
        Effective cost used as edge weight in graph algorithms.
        Incorporates distance and real-time traffic.
        """
        if self.is_blocked:
            return float('inf')
        return self.distance_km * self.traffic_multiplier

    def set_traffic(self, level: TrafficLevel) -> None:
        self.traffic_level = level
        self.traffic_multiplier = {
            TrafficLevel.CLEAR:    1.0,
            TrafficLevel.MODERATE: 1.4,
            TrafficLevel.HEAVY:    2.0,
            TrafficLevel.BLOCKED:  float('inf'),  # consistent with effective_cost
        }[level]
        self.is_blocked = (level == TrafficLevel.BLOCKED)

    def to_dict(self) -> dict:
        return {
            "source_id":          self.source_id,
            "target_id":          self.target_id,
            "distance_km":        round(self.distance_km, 3),
            "traffic_level":      self.traffic_level.value,
            "traffic_multiplier": self.traffic_multiplier,
            "effective_cost":     round(self.effective_cost, 3),
            "is_blocked":         self.is_blocked,
        }
