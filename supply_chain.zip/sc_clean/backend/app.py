"""
app.py — Flask REST API for the Supply Chain Optimization Platform.

All frontend communication goes through these endpoints.
The server runs on http://localhost:5000

Endpoints
---------
GET  /api/state                — Full snapshot of current system state
POST /api/orders               — Add a new delivery order
POST /api/warehouses           — Add a new warehouse
POST /api/trucks               — Add a new truck
POST /api/optimize             — Run full 4-stage optimization pipeline
POST /api/simulate             — Trigger demand spike + traffic event
POST /api/simulate/traffic     — Traffic event only
POST /api/simulate/demand      — Demand spike only
POST /api/reset/traffic        — Reset all traffic to CLEAR
POST /api/reset                — Hard reset entire simulation to seed data
GET  /api/metrics              — Dashboard metrics only (lightweight poll)
GET  /api/route/<src>/<tgt>    — Single route between two nodes (A*)
GET  /health                   — Health check
"""

from __future__ import annotations
import os
import sys
import time
import traceback
import functools

_START = time.time()  # Fix Bug 1: was defined AFTER health() referenced it at line 112

from flask import Flask, jsonify, request, Response
import logging

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(name)s — %(message)s",
)
log = logging.getLogger(__name__)

# Ensure backend/ is on path when running app.py directly
_DIR = os.path.dirname(os.path.abspath(__file__))
if _DIR not in sys.path:
    sys.path.insert(0, _DIR)

from models import (
    Warehouse, DeliveryPoint, Truck, Order,
    Coordinates, OrderPriority, OrderStatus
)
from state import StateManager, load_seed_data
from algorithms.optimizer import optimize
from algorithms.simulator import Simulator
from algorithms.dijkstra import find_route

# ---------------------------------------------------------------------------
# App setup
# ---------------------------------------------------------------------------

app = Flask(__name__)
@app.after_request
def add_cors(response):
    response.headers["Access-Control-Allow-Origin"]  = "*"
    response.headers["Access-Control-Allow-Headers"] = "Content-Type,Authorization"
    response.headers["Access-Control-Allow-Methods"] = "GET,POST,PUT,DELETE,OPTIONS"
    return response

@app.route("/api/<path:path>", methods=["OPTIONS"])
@app.route("/<path:path>", methods=["OPTIONS"])
def options_handler(path=""):
    return app.make_default_options_response()

# Single shared state — created once at startup
state = StateManager()
load_seed_data(state)
simulator = Simulator(state)

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def ok(data: dict | list, status: int = 200) -> Response:
    """Wrap a successful response."""
    return jsonify({"ok": True, "data": data}), status

def err(message: str, status: int = 400) -> Response:
    """Wrap an error response."""
    return jsonify({"ok": False, "error": message}), status

def require_json(*fields: str):
    """
    Decorator: validates that the request body is JSON and contains
    all required fields. Injects the parsed body as first argument.
    """
    def decorator(fn):
        @functools.wraps(fn)
        def wrapper(*args, **kwargs):
            body = request.get_json(silent=True)
            if body is None:
                return err("Request body must be valid JSON")
            missing = [f for f in fields if f not in body]
            if missing:
                return err(f"Missing required fields: {', '.join(missing)}")
            return fn(body, *args, **kwargs)
        return wrapper
    return decorator

# ---------------------------------------------------------------------------
# Health
# ---------------------------------------------------------------------------

@app.route("/health")
def health():
    return ok({"status": "ok", "uptime": round(time.time() - _START, 1)})

# ---------------------------------------------------------------------------
# State snapshot  (polled every 2s by frontend)
# ---------------------------------------------------------------------------

@app.route("/api/state")
def get_state():
    """
    Full system snapshot.
    Returns warehouses, delivery points, trucks, orders, graph, and metrics.
    Called by the frontend every ~2 seconds to refresh the map.
    """
    return ok(state.snapshot())

@app.route("/api/metrics")
def get_metrics():
    """Lightweight metrics-only endpoint for the stats panel."""
    snap = state.snapshot()
    return ok(snap["metrics"])

# ---------------------------------------------------------------------------
# Orders
# ---------------------------------------------------------------------------

@app.route("/api/orders", methods=["POST"])
@require_json("destination_id", "weight_kg")
def add_order(body):
    """
    Add a new delivery order.

    Body:
        destination_id  str    — ID of an existing delivery point
        weight_kg       float  — package weight
        priority        str    — "low" | "standard" | "high" | "critical"  (optional)

    Example:
        POST /api/orders
        {"destination_id": "abc123", "weight_kg": 150, "priority": "high"}
    """
    dp = state.get_delivery_point(body["destination_id"])
    if not dp:
        return err(f"Delivery point '{body['destination_id']}' not found")

    try:
        weight = float(body["weight_kg"])
        if weight <= 0:
            raise ValueError()
    except (ValueError, TypeError):
        return err("weight_kg must be a positive number")

    priority_str = body.get("priority", "standard")
    try:
        priority = OrderPriority(priority_str)
    except ValueError:
        return err(f"Invalid priority '{priority_str}'. Use: low, standard, high, critical")

    order = Order(
        destination=dp.coords,
        weight_kg=weight,
        destination_id=dp.id,
        priority=priority,
    )
    state.add_order(order)
    return ok(order.to_dict(), status=201)

@app.route("/api/orders", methods=["GET"])
def list_orders():
    status_filter = request.args.get("status")
    if status_filter:
        try:
            status_enum = OrderStatus(status_filter)
            orders = state.get_orders_by_status(status_enum)
        except ValueError:
            return err(f"Invalid status '{status_filter}'")
    else:
        orders = list(state.orders.values())
    return ok([o.to_dict() for o in orders])

# ---------------------------------------------------------------------------
# Warehouses
# ---------------------------------------------------------------------------

@app.route("/api/warehouses", methods=["POST"])
@require_json("name", "lat", "lng")
def add_warehouse(body):
    """
    Add a new warehouse node.

    Body:
        name          str    — display name
        lat           float  — latitude
        lng           float  — longitude
        capacity_kg   float  — max storage (optional, default 2000)
        inventory     float  — starting inventory (optional, default = capacity)
    """
    try:
        coords = Coordinates(float(body["lat"]), float(body["lng"]))
    except ValueError as e:
        return err(str(e))

    capacity = float(body.get("capacity_kg", 2000))
    inventory = float(body.get("inventory", capacity))

    wh = Warehouse(
        name=body["name"],
        coords=coords,
        capacity_kg=capacity,
        inventory=min(inventory, capacity),
    )
    state.add_warehouse(wh)
    return ok(wh.to_dict(), status=201)

@app.route("/api/warehouses", methods=["GET"])
def list_warehouses():
    return ok([wh.to_dict() for wh in state.warehouses.values()])

# ---------------------------------------------------------------------------
# Delivery points
# ---------------------------------------------------------------------------

@app.route("/api/delivery-points", methods=["POST"])
@require_json("name", "lat", "lng")
def add_delivery_point(body):
    """
    Add a new delivery destination.

    Body:
        name       str    — display name
        lat        float  — latitude
        lng        float  — longitude
        demand_kg  float  — expected demand (optional)
    """
    try:
        coords = Coordinates(float(body["lat"]), float(body["lng"]))
    except ValueError as e:
        return err(str(e))

    try:
        demand = float(body.get("demand_kg", 0))
        if demand < 0:
            raise ValueError("must be non-negative")
    except (ValueError, TypeError):
        return err("demand_kg must be a non-negative number")

    dp = DeliveryPoint(
        name=body["name"],
        coords=coords,
        demand_kg=demand,
    )
    state.add_delivery_point(dp)
    return ok(dp.to_dict(), status=201)

@app.route("/api/delivery-points", methods=["GET"])
def list_delivery_points():
    return ok([dp.to_dict() for dp in state.delivery_points.values()])

# ---------------------------------------------------------------------------
# Trucks
# ---------------------------------------------------------------------------

@app.route("/api/trucks", methods=["POST"])
@require_json("warehouse_id", "name")
def add_truck(body):
    """
    Add a new truck to a warehouse.

    Body:
        warehouse_id  str    — ID of an existing warehouse
        name          str    — truck label (e.g. "MUM-T4")
        capacity_kg   float  — optional, default 1000
        speed_kmh     float  — optional, default 60
    """
    if not state.get_warehouse(body["warehouse_id"]):
        return err(f"Warehouse '{body['warehouse_id']}' not found")

    try:
        cap = float(body.get("capacity_kg", 1000))
        spd = float(body.get("speed_kmh", 60))
        if cap <= 0 or spd <= 0:
            raise ValueError("must be positive")
    except (ValueError, TypeError):
        return err("capacity_kg and speed_kmh must be positive numbers")

    truck = Truck(
        warehouse_id=body["warehouse_id"],
        name=body["name"],
        capacity_kg=cap,
        speed_kmh=spd,
    )
    state.add_truck(truck)
    return ok(truck.to_dict(), status=201)

@app.route("/api/trucks", methods=["GET"])
def list_trucks():
    return ok([t.to_dict() for t in state.trucks.values()])

# ---------------------------------------------------------------------------
# Optimize
# ---------------------------------------------------------------------------

@app.route("/api/optimize", methods=["POST"])
def run_optimize():
    """
    Run the full 4-stage optimization pipeline:
        1. Min-Cost Flow  → assign orders to warehouses
        2. VRP            → assign orders to trucks + build routes
        3. DP-TSP         → refine stop order (≤15 stops)
        4. State update   → persist routes into StateManager

    No body required. Returns the full OptimizationResult + updated state snapshot.
    """
    pending = state.get_pending_orders()
    if not pending:
        return ok({
            "message": "No pending orders to optimize",
            "orders_routed": 0,
            "trucks_dispatched": 0,
        })

    try:
        result = optimize(state)
        return ok({
            "optimization": result.to_dict(),
            "snapshot":     state.snapshot(),
        })
    except Exception as e:
        traceback.print_exc()
        return err(f"Optimization failed: {str(e)}", status=500)

# ---------------------------------------------------------------------------
# Simulate
# ---------------------------------------------------------------------------

@app.route("/api/simulate", methods=["POST"])
def run_simulate():
    """
    Run a full simulation step: demand spike + traffic event.

    Body (all optional):
        n_orders    int    — number of orders to inject (default 8)
        severity    str    — "minor" | "moderate" | "major" (default "moderate")
        seed        int    — random seed for reproducibility
        spike       bool   — include demand spike (default true)
        traffic     bool   — include traffic event (default true)
    """
    body = request.get_json(silent=True) or {}

    result = simulator.full_simulation(
        n_orders=int(body.get("n_orders", 8)),
        severity=body.get("severity", "moderate"),
        include_spike=bool(body.get("spike", True)),
        include_traffic=bool(body.get("traffic", True)),
        seed=body.get("seed"),
    )
    return ok({
        "simulation": result.to_dict(),
        "snapshot":   state.snapshot(),
    })

@app.route("/api/simulate/demand", methods=["POST"])
def run_demand_spike():
    """Demand spike only."""
    body = request.get_json(silent=True) or {}
    result = simulator.demand_spike(
        n_orders=int(body.get("n_orders", 8)),
        seed=body.get("seed"),
    )
    return ok({"simulation": result.to_dict(), "snapshot": state.snapshot()})

@app.route("/api/simulate/traffic", methods=["POST"])
def run_traffic_event():
    """Traffic event only."""
    body = request.get_json(silent=True) or {}
    result = simulator.traffic_event(
        severity=body.get("severity", "moderate"),
        seed=body.get("seed"),
    )
    return ok({"simulation": result.to_dict(), "snapshot": state.snapshot()})

# ---------------------------------------------------------------------------
# Reset
# ---------------------------------------------------------------------------

@app.route("/api/reset/traffic", methods=["POST"])
def reset_traffic():
    """Reset all road edges to CLEAR traffic conditions."""
    n = simulator.reset_traffic()
    return ok({"edges_reset": n, "snapshot": state.snapshot()})

@app.route("/api/reset", methods=["POST"])
def reset_all():
    """
    Hard reset: wipe all runtime state and reload seed data.
    All trucks return to IDLE, all orders cleared, traffic cleared.
    """
    state.hard_reset()
    load_seed_data(state)
    simulator._injected_order_ids.clear()
    return ok({"message": "System reset to initial state", "snapshot": state.snapshot()})

# ---------------------------------------------------------------------------
# Single-pair routing
# ---------------------------------------------------------------------------

@app.route("/api/route/<source_id>/<target_id>")
def get_route(source_id: str, target_id: str):
    """
    Compute the optimal route between two nodes using A*.
    Useful for previewing routes on the map before optimizing.

    Query params:
        algorithm  — "astar" (default) | "dijkstra"
    """
    algorithm = request.args.get("algorithm", "astar")

    if not state.graph.node_exists(source_id):
        return err(f"Source node '{source_id}' not found")
    if not state.graph.node_exists(target_id):
        return err(f"Target node '{target_id}' not found")

    result = find_route(state.graph, source_id, target_id, algorithm=algorithm)
    return ok(result.to_dict())

# ---------------------------------------------------------------------------
# Traffic summary
# ---------------------------------------------------------------------------

@app.route("/api/traffic")
def get_traffic():
    """Current traffic conditions across the network."""
    return ok(simulator.get_traffic_summary())

# ---------------------------------------------------------------------------
# Error handlers
# ---------------------------------------------------------------------------

@app.errorhandler(404)
def not_found(e):
    return err("Endpoint not found", status=404)

@app.errorhandler(405)
def method_not_allowed(e):
    return err("Method not allowed", status=405)

@app.errorhandler(500)
def internal_error(e):
    return err("Internal server error", status=500)

# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# Mark order delivered
# ---------------------------------------------------------------------------

@app.route("/api/orders/<order_id>/deliver", methods=["POST"])
def deliver_order(order_id: str):
    """Mark a specific order as delivered and return the truck to idle."""
    order = state.get_order(order_id)
    if not order:
        return err(f"Order '{order_id}' not found", status=404)
    if order.status.value not in ("in_transit", "assigned"):
        return err(f"Order is '{order.status.value}', must be in_transit or assigned to deliver")

    # Free the truck
    if order.truck_id:
        truck = state.get_truck(order.truck_id)
        if truck:
            truck.assigned_orders = [o for o in truck.assigned_orders if o != order_id]
            truck.current_load = max(0.0, truck.current_load - order.weight_kg)
            if not truck.assigned_orders:
                truck.reset()

    state.mark_order_delivered(order_id)
    return ok({"order": order.to_dict(), "snapshot": state.snapshot()})

# ---------------------------------------------------------------------------
# Bulk deliver all in-transit orders (simulate completion)
# ---------------------------------------------------------------------------

@app.route("/api/orders/deliver-all", methods=["POST"])
def deliver_all():
    """Deliver all in-transit orders at once — useful for resetting after demo."""
    in_transit = state.get_orders_by_status(OrderStatus.IN_TRANSIT)
    in_transit += state.get_orders_by_status(OrderStatus.ASSIGNED)
    count = 0
    for order in in_transit:
        if order.truck_id:
            truck = state.get_truck(order.truck_id)
            if truck:
                truck.assigned_orders = [o for o in truck.assigned_orders if o != order.id]
                truck.current_load = max(0.0, truck.current_load - order.weight_kg)
                if not truck.assigned_orders:
                    truck.reset()
        state.mark_order_delivered(order.id)
        count += 1
    return ok({"delivered_count": count, "snapshot": state.snapshot()})

# ---------------------------------------------------------------------------
# Graph stats endpoint
# ---------------------------------------------------------------------------

@app.route("/api/graph")
def get_graph():
    """Full graph data with traffic — for detailed map overlays."""
    return ok(state.graph.to_dict())

# ---------------------------------------------------------------------------
# Entry point  ← ALWAYS LAST in the file
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    port = int(os.environ.get("FLASK_PORT", 5000))
    debug = os.environ.get("FLASK_DEBUG", "True").lower() == "true"

    log.info("=" * 55)
    log.info("  Supply Chain Optimization Platform — API Server")
    log.info("=" * 55)
    log.info("  URL      : http://localhost:%d", port)
    log.info("  Debug    : %s", debug)
    log.info("  Warehouses loaded : %d", len(state.warehouses))
    log.info("  Trucks loaded     : %d", len(state.trucks))
    log.info("  Delivery points   : %d", len(state.delivery_points))
    log.info("=" * 55)
    log.info("  Endpoints: GET /api/state | POST /api/optimize | POST /api/simulate | POST /api/orders | POST /api/reset | GET /health")

    app.run(host="0.0.0.0", port=port, debug=debug)
