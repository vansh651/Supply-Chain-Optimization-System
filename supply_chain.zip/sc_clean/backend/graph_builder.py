"""
graph_builder.py — Constructs and maintains the NetworkX road network graph.

"""

from __future__ import annotations
from typing import Optional
import math
import networkx as nx

from models import (
    Warehouse, DeliveryPoint, RoadEdge,
    NodeType, TrafficLevel, Coordinates
)

def _haversine_km(lat1: float, lng1: float, lat2: float, lng2: float) -> float:
    R = 6371.0
    phi1, phi2 = math.radians(lat1), math.radians(lat2)
    dphi = math.radians(lat2 - lat1)
    dlng = math.radians(lng2 - lng1)
    a = math.sin(dphi / 2) ** 2 + math.cos(phi1) * math.cos(phi2) * math.sin(dlng / 2) ** 2
    return R * 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))

class GraphBuilder:
    """
    Builds and manages the supply chain road network as a NetworkX DiGraph.

    Node attributes:
        type, coords, label (and capacity/inventory for warehouses)

    Edge attributes:
        weight     — effective cost (distance * traffic multiplier)
        distance   — raw distance in km
        traffic    — TrafficLevel enum value
        multiplier — float traffic multiplier

        It is set True whenever any edge gets a negative weight.
        It is set False only during reset_all_traffic() when all weights
        are known to be non-negative again.
        This replaces the O(E) full scan that ran on every route call.

        so that remove_node() is O(degree) not O(E).
    """

    def __init__(self):
        self.G: nx.DiGraph = nx.DiGraph()
        self._edges: dict[tuple[str, str], RoadEdge] = {}
        self._out_edges: dict[str, set[str]] = {}   # src -> {tgt, ...}
        self._in_edges:  dict[str, set[str]] = {}   # tgt -> {src, ...}
        self._has_neg_weight: bool = False

    @property
    def has_negative_weights(self) -> bool:
        """O(1) negative edge weight check."""
        return self._has_neg_weight

    # ------------------------------------------------------------------
    # Node management
    # ------------------------------------------------------------------

    def add_warehouse(self, wh: Warehouse) -> None:
        self.G.add_node(
            wh.id,
            type=NodeType.WAREHOUSE.value,
            coords=wh.coords,
            label=wh.name,
            capacity=wh.capacity_kg,
            inventory=wh.inventory,
        )
        # Ensure index entries exist
        self._out_edges.setdefault(wh.id, set())
        self._in_edges.setdefault(wh.id, set())

    def add_delivery_point(self, dp: DeliveryPoint) -> None:
        self.G.add_node(
            dp.id,
            type=NodeType.DELIVERY.value,
            coords=dp.coords,
            label=dp.name,
            demand=dp.demand_kg,
        )
        self._out_edges.setdefault(dp.id, set())
        self._in_edges.setdefault(dp.id, set())

    def remove_node(self, node_id: str) -> None:
        """
        Original was O(E): `[k for k in self._edges if k[0]==id or k[1]==id]`
        """
        if node_id not in self.G:
            return
        # Remove all outgoing edges
        for tgt in list(self._out_edges.get(node_id, [])):
            self._edges.pop((node_id, tgt), None)
            self._in_edges.get(tgt, set()).discard(node_id)
        # Remove all incoming edges
        for src in list(self._in_edges.get(node_id, [])):
            self._edges.pop((src, node_id), None)
            self._out_edges.get(src, set()).discard(node_id)
        # Clean up index entries
        self._out_edges.pop(node_id, None)
        self._in_edges.pop(node_id, None)
        self.G.remove_node(node_id)
        # Recheck flag conservatively (node removal cannot add negatives,
        # but if we previously set the flag due to this node's edges, we
        # might be able to clear it. Simple safe approach: keep flag set
        # until reset_all_traffic() is called explicitly.)

    # ------------------------------------------------------------------
    # Edge management
    # ------------------------------------------------------------------

    def add_edge(
        self,
        source_id: str,
        target_id: str,
        distance_km: Optional[float] = None,
        bidirectional: bool = True,
    ) -> None:
        if source_id not in self.G:
            raise ValueError(f"Source node '{source_id}' not in graph")
        if target_id not in self.G:
            raise ValueError(f"Target node '{target_id}' not in graph")

        if distance_km is None:
            distance_km = self._haversine(source_id, target_id)

        edge = RoadEdge(source_id=source_id, target_id=target_id, distance_km=distance_km)
        self._edges[(source_id, target_id)] = edge
        self._out_edges.setdefault(source_id, set()).add(target_id)
        self._in_edges.setdefault(target_id, set()).add(source_id)
        self.G.add_edge(
            source_id, target_id,
            weight=edge.effective_cost,
            distance=distance_km,
            traffic=edge.traffic_level.value,
            multiplier=edge.traffic_multiplier,
        )
        if edge.effective_cost < 0:
            self._has_neg_weight = True

        if bidirectional:
            reverse_edge = RoadEdge(source_id=target_id, target_id=source_id, distance_km=distance_km)
            self._edges[(target_id, source_id)] = reverse_edge
            self._out_edges.setdefault(target_id, set()).add(source_id)
            self._in_edges.setdefault(source_id, set()).add(target_id)
            self.G.add_edge(
                target_id, source_id,
                weight=reverse_edge.effective_cost,
                distance=distance_km,
                traffic=reverse_edge.traffic_level.value,
                multiplier=reverse_edge.traffic_multiplier,
            )
            if reverse_edge.effective_cost < 0:
                self._has_neg_weight = True

    def connect_all_to_all(self, node_ids: list[str]) -> None:
        for i, src in enumerate(node_ids):
            for tgt in node_ids[i + 1:]:
                if not self.G.has_edge(src, tgt):
                    self.add_edge(src, tgt, bidirectional=True)

    # ------------------------------------------------------------------
    # Traffic management
    # ------------------------------------------------------------------

    def set_traffic(self, source_id: str, target_id: str, level: TrafficLevel) -> None:
        key = (source_id, target_id)
        if key not in self._edges:
            raise KeyError(f"Edge ({source_id} → {target_id}) not found")

        edge = self._edges[key]
        edge.set_traffic(level)

        self.G[source_id][target_id]['weight']     = edge.effective_cost
        self.G[source_id][target_id]['traffic']    = edge.traffic_level.value
        self.G[source_id][target_id]['multiplier'] = edge.traffic_multiplier

        if edge.effective_cost < 0:
            self._has_neg_weight = True
        # Note: we don't clear the flag here because other edges may still
        # be negative. The flag is only cleared by reset_all_traffic().

    def reset_all_traffic(self) -> None:
        """Reset every edge to TrafficLevel.CLEAR and clear the negative-weight flag."""
        for key in self._edges:
            self._edges[key].set_traffic(TrafficLevel.CLEAR)
            src, tgt = key
            self.G[src][tgt]['weight']     = self._edges[key].effective_cost
            self.G[src][tgt]['traffic']    = TrafficLevel.CLEAR.value
            self.G[src][tgt]['multiplier'] = 1.0
        self._has_neg_weight = False

    def update_inventory(self, warehouse_id: str, inventory: float) -> None:
        if warehouse_id in self.G:
            self.G.nodes[warehouse_id]['inventory'] = inventory

    # ------------------------------------------------------------------
    # Queries
    # ------------------------------------------------------------------

    def get_edge(self, source_id: str, target_id: str) -> Optional[RoadEdge]:
        return self._edges.get((source_id, target_id))

    def get_node_coords(self, node_id: str) -> Optional[Coordinates]:
        node = self.G.nodes.get(node_id)
        return node['coords'] if node else None

    def get_warehouses(self) -> list[str]:
        return [n for n, d in self.G.nodes(data=True) if d.get('type') == NodeType.WAREHOUSE.value]

    def get_delivery_points(self) -> list[str]:
        return [n for n, d in self.G.nodes(data=True) if d.get('type') == NodeType.DELIVERY.value]

    def node_exists(self, node_id: str) -> bool:
        return node_id in self.G

    def edge_exists(self, source_id: str, target_id: str) -> bool:
        return self.G.has_edge(source_id, target_id)

    @property
    def node_count(self) -> int:
        return self.G.number_of_nodes()

    @property
    def edge_count(self) -> int:
        return self.G.number_of_edges()

    def is_connected(self) -> bool:
        if self.G.number_of_nodes() == 0:
            return True
        return nx.is_weakly_connected(self.G)

    def to_dict(self) -> dict:
        nodes = []
        for node_id, data in self.G.nodes(data=True):
            coords = data.get('coords')
            nodes.append({
                "id":     node_id,
                "type":   data.get('type'),
                "label":  data.get('label'),
                "coords": coords.to_dict() if coords else None,
            })

        edges = []
        for src, tgt, data in self.G.edges(data=True):
            edges.append({
                "source":     src,
                "target":     tgt,
                "weight":     round(data.get('weight', 0), 3),
                "distance":   round(data.get('distance', 0), 3),
                "traffic":    data.get('traffic', 'clear'),
                "multiplier": data.get('multiplier', 1.0),
            })

        return {
            "node_count":   self.node_count,
            "edge_count":   self.edge_count,
            "is_connected": self.is_connected(),
            "nodes":        nodes,
            "edges":        edges,
        }

    def _haversine(self, node_a: str, node_b: str) -> float:
        coords_a = self.G.nodes[node_a]['coords']
        coords_b = self.G.nodes[node_b]['coords']
        return _haversine_km(coords_a.lat, coords_a.lng, coords_b.lat, coords_b.lng)
